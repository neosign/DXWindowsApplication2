﻿namespace DXWindowsApplication2.UserForms
{
    partial class Recording_PMeter
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            this.panelControl8 = new DevExpress.XtraEditors.PanelControl();
            this.bttEdit = new DevExpress.XtraEditors.SimpleButton();
            this.bttCancel = new DevExpress.XtraEditors.SimpleButton();
            this.bttSave = new DevExpress.XtraEditors.SimpleButton();
            this.bttReplace = new DevExpress.XtraEditors.SimpleButton();
            this.labelControlBuilding = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEditBuilding = new DevExpress.XtraEditors.LookUpEdit();
            this.groupControlPMeter = new DevExpress.XtraEditors.GroupControl();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.timeEditTime = new DevExpress.XtraEditors.TimeEdit();
            this.bttSet = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEditRecordDate = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControlRecordDate = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEdit1 = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.xtraScrollableControl1 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.groupBoxMeterInRoom = new System.Windows.Forms.GroupBox();
            this.gridControlPhone = new DevExpress.XtraGrid.GridControl();
            this.gridViewPhone = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumnRoomName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnMeterName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPreviousDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPreviousTime = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTimeEditPrevious = new DevExpress.XtraEditors.Repository.RepositoryItemTimeEdit();
            this.gridColumnPresentDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPresentTime = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTimeEditPresent = new DevExpress.XtraEditors.Repository.RepositoryItemTimeEdit();
            this.gridColumnTotalUnit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnReading = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditReading = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumnPreviousTimeTemp = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPreviousDateTemp = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnE_MeterID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnFlag = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl8)).BeginInit();
            this.panelControl8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditBuilding.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlPMeter)).BeginInit();
            this.groupControlPMeter.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timeEditTime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditRecordDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            this.xtraScrollableControl1.SuspendLayout();
            this.groupBoxMeterInRoom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlPhone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewPhone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTimeEditPrevious)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTimeEditPresent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditReading)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl8
            // 
            this.panelControl8.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
            this.panelControl8.Appearance.Options.UseBackColor = true;
            this.panelControl8.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.panelControl8.Controls.Add(this.bttEdit);
            this.panelControl8.Controls.Add(this.bttCancel);
            this.panelControl8.Controls.Add(this.bttSave);
            this.panelControl8.Controls.Add(this.bttReplace);
            this.panelControl8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelControl8.Location = new System.Drawing.Point(7, 557);
            this.panelControl8.Name = "panelControl8";
            this.panelControl8.Size = new System.Drawing.Size(1088, 83);
            this.panelControl8.TabIndex = 419;
            // 
            // bttEdit
            // 
            this.bttEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bttEdit.Image = global::DXWindowsApplication2.Properties.Resources.edit;
            this.bttEdit.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.bttEdit.Location = new System.Drawing.Point(863, 22);
            this.bttEdit.Name = "bttEdit";
            this.bttEdit.Size = new System.Drawing.Size(70, 55);
            this.bttEdit.TabIndex = 19;
            this.bttEdit.Text = "แก้ไขข้อมูล";
            this.bttEdit.Click += new System.EventHandler(this.bttEdit_Click);
            // 
            // bttCancel
            // 
            this.bttCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bttCancel.Enabled = false;
            this.bttCancel.Image = global::DXWindowsApplication2.Properties.Resources.Close;
            this.bttCancel.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.bttCancel.Location = new System.Drawing.Point(1015, 22);
            this.bttCancel.Name = "bttCancel";
            this.bttCancel.Size = new System.Drawing.Size(70, 55);
            this.bttCancel.TabIndex = 22;
            this.bttCancel.Text = "ยกเลิก";
            // 
            // bttSave
            // 
            this.bttSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bttSave.Enabled = false;
            this.bttSave.Image = global::DXWindowsApplication2.Properties.Resources.savedisk;
            this.bttSave.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.bttSave.Location = new System.Drawing.Point(939, 22);
            this.bttSave.Name = "bttSave";
            this.bttSave.Size = new System.Drawing.Size(70, 55);
            this.bttSave.TabIndex = 21;
            this.bttSave.Text = "บันทึก";
            this.bttSave.Click += new System.EventHandler(this.bttSave_Click);
            // 
            // bttReplace
            // 
            this.bttReplace.Image = global::DXWindowsApplication2.Properties.Resources.refresh;
            this.bttReplace.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleLeft;
            this.bttReplace.Location = new System.Drawing.Point(7, 22);
            this.bttReplace.Name = "bttReplace";
            this.bttReplace.Size = new System.Drawing.Size(94, 55);
            this.bttReplace.TabIndex = 431;
            this.bttReplace.Text = "Read All";
            // 
            // labelControlBuilding
            // 
            this.labelControlBuilding.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControlBuilding.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControlBuilding.Location = new System.Drawing.Point(7, 37);
            this.labelControlBuilding.Name = "labelControlBuilding";
            this.labelControlBuilding.Size = new System.Drawing.Size(72, 17);
            this.labelControlBuilding.TabIndex = 22;
            this.labelControlBuilding.Text = "อาคาร :";
            // 
            // lookUpEditBuilding
            // 
            this.lookUpEditBuilding.Location = new System.Drawing.Point(85, 36);
            this.lookUpEditBuilding.Name = "lookUpEditBuilding";
            this.lookUpEditBuilding.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditBuilding.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("building_id", "", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("building_code", " ")});
            this.lookUpEditBuilding.Size = new System.Drawing.Size(139, 20);
            this.lookUpEditBuilding.TabIndex = 21;
            // 
            // groupControlPMeter
            // 
            this.groupControlPMeter.Controls.Add(this.groupBox1);
            this.groupControlPMeter.Controls.Add(this.lookUpEdit1);
            this.groupControlPMeter.Controls.Add(this.labelControl1);
            this.groupControlPMeter.Controls.Add(this.lookUpEditBuilding);
            this.groupControlPMeter.Controls.Add(this.labelControlBuilding);
            this.groupControlPMeter.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupControlPMeter.Location = new System.Drawing.Point(7, 7);
            this.groupControlPMeter.Name = "groupControlPMeter";
            this.groupControlPMeter.Size = new System.Drawing.Size(1088, 84);
            this.groupControlPMeter.TabIndex = 0;
            this.groupControlPMeter.Text = "Phone";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.timeEditTime);
            this.groupBox1.Controls.Add(this.bttSet);
            this.groupBox1.Controls.Add(this.labelControl2);
            this.groupBox1.Controls.Add(this.lookUpEditRecordDate);
            this.groupBox1.Controls.Add(this.labelControlRecordDate);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox1.Location = new System.Drawing.Point(577, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(509, 60);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Present Record Daate and Time";
            // 
            // timeEditTime
            // 
            this.timeEditTime.EditValue = new System.DateTime(2012, 8, 5, 12, 0, 0, 0);
            this.timeEditTime.Location = new System.Drawing.Point(274, 24);
            this.timeEditTime.Name = "timeEditTime";
            this.timeEditTime.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.timeEditTime.Size = new System.Drawing.Size(136, 20);
            this.timeEditTime.TabIndex = 28;
            // 
            // bttSet
            // 
            this.bttSet.Location = new System.Drawing.Point(424, 15);
            this.bttSet.Name = "bttSet";
            this.bttSet.Size = new System.Drawing.Size(75, 39);
            this.bttSet.TabIndex = 27;
            this.bttSet.Text = "Set";
            // 
            // labelControl2
            // 
            this.labelControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl2.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl2.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl2.Location = new System.Drawing.Point(7, 25);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(64, 17);
            this.labelControl2.TabIndex = 26;
            this.labelControl2.Text = " Date :";
            // 
            // lookUpEditRecordDate
            // 
            this.lookUpEditRecordDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lookUpEditRecordDate.Location = new System.Drawing.Point(77, 24);
            this.lookUpEditRecordDate.Name = "lookUpEditRecordDate";
            this.lookUpEditRecordDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditRecordDate.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("groupdate", "", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("groupdate", " ", 20, DevExpress.Utils.FormatType.DateTime, "d", true, DevExpress.Utils.HorzAlignment.Default)});
            this.lookUpEditRecordDate.Properties.DisplayFormat.FormatString = "d";
            this.lookUpEditRecordDate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.lookUpEditRecordDate.Properties.EditFormat.FormatString = "d";
            this.lookUpEditRecordDate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.lookUpEditRecordDate.Size = new System.Drawing.Size(139, 20);
            this.lookUpEditRecordDate.TabIndex = 25;
            // 
            // labelControlRecordDate
            // 
            this.labelControlRecordDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControlRecordDate.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControlRecordDate.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControlRecordDate.Location = new System.Drawing.Point(222, 25);
            this.labelControlRecordDate.Name = "labelControlRecordDate";
            this.labelControlRecordDate.Size = new System.Drawing.Size(46, 17);
            this.labelControlRecordDate.TabIndex = 24;
            this.labelControlRecordDate.Text = "Time :";
            // 
            // lookUpEdit1
            // 
            this.lookUpEdit1.Location = new System.Drawing.Point(387, 36);
            this.lookUpEdit1.Name = "lookUpEdit1";
            this.lookUpEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit1.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("building_id", "", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("building_code", " ")});
            this.lookUpEdit1.Size = new System.Drawing.Size(139, 20);
            this.lookUpEdit1.TabIndex = 25;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl1.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl1.Location = new System.Drawing.Point(230, 37);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(151, 17);
            this.labelControl1.TabIndex = 26;
            this.labelControl1.Text = "PABX Brand/Model :";
            // 
            // gridView2
            // 
            this.gridView2.Name = "gridView2";
            // 
            // xtraScrollableControl1
            // 
            this.xtraScrollableControl1.Controls.Add(this.groupBoxMeterInRoom);
            this.xtraScrollableControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl1.Location = new System.Drawing.Point(7, 91);
            this.xtraScrollableControl1.Name = "xtraScrollableControl1";
            this.xtraScrollableControl1.Size = new System.Drawing.Size(1088, 466);
            this.xtraScrollableControl1.TabIndex = 420;
            // 
            // groupBoxMeterInRoom
            // 
            this.groupBoxMeterInRoom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
            this.groupBoxMeterInRoom.Controls.Add(this.gridControlPhone);
            this.groupBoxMeterInRoom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxMeterInRoom.Location = new System.Drawing.Point(0, 0);
            this.groupBoxMeterInRoom.Name = "groupBoxMeterInRoom";
            this.groupBoxMeterInRoom.Size = new System.Drawing.Size(1088, 466);
            this.groupBoxMeterInRoom.TabIndex = 3;
            this.groupBoxMeterInRoom.TabStop = false;
            // 
            // gridControlPhone
            // 
            this.gridControlPhone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlPhone.Location = new System.Drawing.Point(3, 17);
            this.gridControlPhone.MainView = this.gridViewPhone;
            this.gridControlPhone.Name = "gridControlPhone";
            this.gridControlPhone.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEditReading,
            this.repositoryItemTimeEditPrevious,
            this.repositoryItemTimeEditPresent});
            this.gridControlPhone.Size = new System.Drawing.Size(1082, 446);
            this.gridControlPhone.TabIndex = 0;
            this.gridControlPhone.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewPhone});
            // 
            // gridViewPhone
            // 
            this.gridViewPhone.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumnRoomName,
            this.gridColumnMeterName,
            this.gridColumnPreviousDate,
            this.gridColumnPreviousTime,
            this.gridColumnPresentDate,
            this.gridColumnPresentTime,
            this.gridColumnTotalUnit,
            this.gridColumnReading,
            this.gridColumnPreviousTimeTemp,
            this.gridColumnPreviousDateTemp,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumnE_MeterID,
            this.gridColumnFlag});
            this.gridViewPhone.GridControl = this.gridControlPhone;
            this.gridViewPhone.Name = "gridViewPhone";
            this.gridViewPhone.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumnRoomName
            // 
            this.gridColumnRoomName.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnRoomName.AppearanceHeader.Options.UseFont = true;
            this.gridColumnRoomName.Caption = "Room Name";
            this.gridColumnRoomName.FieldName = "room_label";
            this.gridColumnRoomName.Name = "gridColumnRoomName";
            this.gridColumnRoomName.OptionsColumn.AllowEdit = false;
            this.gridColumnRoomName.OptionsColumn.AllowFocus = false;
            this.gridColumnRoomName.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnRoomName.OptionsColumn.AllowMove = false;
            this.gridColumnRoomName.OptionsColumn.ReadOnly = true;
            this.gridColumnRoomName.Visible = true;
            this.gridColumnRoomName.VisibleIndex = 0;
            this.gridColumnRoomName.Width = 49;
            // 
            // gridColumnMeterName
            // 
            this.gridColumnMeterName.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnMeterName.AppearanceHeader.Options.UseFont = true;
            this.gridColumnMeterName.Caption = "Phone No";
            this.gridColumnMeterName.FieldName = "phone_label";
            this.gridColumnMeterName.Name = "gridColumnMeterName";
            this.gridColumnMeterName.OptionsColumn.AllowEdit = false;
            this.gridColumnMeterName.OptionsColumn.AllowFocus = false;
            this.gridColumnMeterName.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnMeterName.OptionsColumn.AllowMove = false;
            this.gridColumnMeterName.OptionsColumn.ReadOnly = true;
            this.gridColumnMeterName.Visible = true;
            this.gridColumnMeterName.VisibleIndex = 1;
            this.gridColumnMeterName.Width = 62;
            // 
            // gridColumnPreviousDate
            // 
            this.gridColumnPreviousDate.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnPreviousDate.AppearanceHeader.Options.UseFont = true;
            this.gridColumnPreviousDate.Caption = "Previous Date (Billing)";
            this.gridColumnPreviousDate.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumnPreviousDate.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumnPreviousDate.FieldName = "previous_date_billing";
            this.gridColumnPreviousDate.Name = "gridColumnPreviousDate";
            this.gridColumnPreviousDate.OptionsColumn.AllowEdit = false;
            this.gridColumnPreviousDate.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPreviousDate.OptionsColumn.AllowMove = false;
            this.gridColumnPreviousDate.Visible = true;
            this.gridColumnPreviousDate.VisibleIndex = 2;
            this.gridColumnPreviousDate.Width = 86;
            // 
            // gridColumnPreviousTime
            // 
            this.gridColumnPreviousTime.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnPreviousTime.AppearanceHeader.Options.UseFont = true;
            this.gridColumnPreviousTime.Caption = "Previous Time (Billing)";
            this.gridColumnPreviousTime.ColumnEdit = this.repositoryItemTimeEditPrevious;
            this.gridColumnPreviousTime.FieldName = "previous_time_billing_x";
            this.gridColumnPreviousTime.Name = "gridColumnPreviousTime";
            this.gridColumnPreviousTime.OptionsColumn.AllowEdit = false;
            this.gridColumnPreviousTime.OptionsColumn.AllowGroup = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPreviousTime.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPreviousTime.OptionsColumn.AllowMove = false;
            this.gridColumnPreviousTime.Visible = true;
            this.gridColumnPreviousTime.VisibleIndex = 3;
            this.gridColumnPreviousTime.Width = 94;
            // 
            // repositoryItemTimeEditPrevious
            // 
            this.repositoryItemTimeEditPrevious.AutoHeight = false;
            this.repositoryItemTimeEditPrevious.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemTimeEditPrevious.Mask.EditMask = "HH:mm:ss";
            this.repositoryItemTimeEditPrevious.Mask.UseMaskAsDisplayFormat = true;
            this.repositoryItemTimeEditPrevious.Name = "repositoryItemTimeEditPrevious";
            // 
            // gridColumnPresentDate
            // 
            this.gridColumnPresentDate.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnPresentDate.AppearanceHeader.Options.UseFont = true;
            this.gridColumnPresentDate.Caption = "Present Date";
            this.gridColumnPresentDate.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumnPresentDate.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumnPresentDate.FieldName = "p_end_date";
            this.gridColumnPresentDate.Name = "gridColumnPresentDate";
            this.gridColumnPresentDate.OptionsColumn.AllowEdit = false;
            this.gridColumnPresentDate.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPresentDate.OptionsColumn.AllowMove = false;
            this.gridColumnPresentDate.Visible = true;
            this.gridColumnPresentDate.VisibleIndex = 4;
            this.gridColumnPresentDate.Width = 81;
            // 
            // gridColumnPresentTime
            // 
            this.gridColumnPresentTime.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnPresentTime.AppearanceHeader.Options.UseFont = true;
            this.gridColumnPresentTime.Caption = "Present Time";
            this.gridColumnPresentTime.ColumnEdit = this.repositoryItemTimeEditPresent;
            this.gridColumnPresentTime.DisplayFormat.FormatString = "{0:HH:mm:ss}";
            this.gridColumnPresentTime.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumnPresentTime.FieldName = "p_end_time_x";
            this.gridColumnPresentTime.Name = "gridColumnPresentTime";
            this.gridColumnPresentTime.OptionsColumn.AllowEdit = false;
            this.gridColumnPresentTime.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPresentTime.OptionsColumn.AllowMove = false;
            this.gridColumnPresentTime.Visible = true;
            this.gridColumnPresentTime.VisibleIndex = 5;
            this.gridColumnPresentTime.Width = 82;
            // 
            // repositoryItemTimeEditPresent
            // 
            this.repositoryItemTimeEditPresent.AutoHeight = false;
            this.repositoryItemTimeEditPresent.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemTimeEditPresent.Mask.EditMask = "HH:mm:ss";
            this.repositoryItemTimeEditPresent.Mask.UseMaskAsDisplayFormat = true;
            this.repositoryItemTimeEditPresent.Name = "repositoryItemTimeEditPresent";
            // 
            // gridColumnTotalUnit
            // 
            this.gridColumnTotalUnit.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnTotalUnit.AppearanceHeader.Options.UseFont = true;
            this.gridColumnTotalUnit.Caption = "Amount";
            this.gridColumnTotalUnit.DisplayFormat.FormatString = "n1";
            this.gridColumnTotalUnit.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnTotalUnit.FieldName = "total_unit";
            this.gridColumnTotalUnit.Name = "gridColumnTotalUnit";
            this.gridColumnTotalUnit.OptionsColumn.AllowEdit = false;
            this.gridColumnTotalUnit.OptionsColumn.AllowFocus = false;
            this.gridColumnTotalUnit.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnTotalUnit.OptionsColumn.AllowMove = false;
            this.gridColumnTotalUnit.OptionsColumn.ReadOnly = true;
            this.gridColumnTotalUnit.Visible = true;
            this.gridColumnTotalUnit.VisibleIndex = 6;
            this.gridColumnTotalUnit.Width = 49;
            // 
            // gridColumnReading
            // 
            this.gridColumnReading.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnReading.AppearanceHeader.Options.UseFont = true;
            this.gridColumnReading.Caption = "Read";
            this.gridColumnReading.ColumnEdit = this.repositoryItemButtonEditReading;
            this.gridColumnReading.Name = "gridColumnReading";
            this.gridColumnReading.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnReading.OptionsColumn.AllowMove = false;
            this.gridColumnReading.OptionsColumn.ReadOnly = true;
            this.gridColumnReading.Visible = true;
            this.gridColumnReading.VisibleIndex = 7;
            this.gridColumnReading.Width = 31;
            // 
            // repositoryItemButtonEditReading
            // 
            this.repositoryItemButtonEditReading.AccessibleDescription = "Read";
            this.repositoryItemButtonEditReading.AccessibleName = "Read";
            this.repositoryItemButtonEditReading.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.repositoryItemButtonEditReading.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Ellipsis, "Read", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, true)});
            this.repositoryItemButtonEditReading.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.repositoryItemButtonEditReading.Name = "repositoryItemButtonEditReading";
            this.repositoryItemButtonEditReading.NullText = "Read";
            this.repositoryItemButtonEditReading.NullValuePrompt = "Read";
            this.repositoryItemButtonEditReading.NullValuePromptShowForEmptyValue = true;
            this.repositoryItemButtonEditReading.ReadOnly = true;
            this.repositoryItemButtonEditReading.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditReading.UseParentBackground = true;
            // 
            // gridColumnPreviousTimeTemp
            // 
            this.gridColumnPreviousTimeTemp.Caption = "previous_time_billingTemp ( Temp )";
            this.gridColumnPreviousTimeTemp.DisplayFormat.FormatString = "HH:mm:ss";
            this.gridColumnPreviousTimeTemp.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumnPreviousTimeTemp.FieldName = "previous_time_billingTemp";
            this.gridColumnPreviousTimeTemp.Name = "gridColumnPreviousTimeTemp";
            this.gridColumnPreviousTimeTemp.Width = 106;
            // 
            // gridColumnPreviousDateTemp
            // 
            this.gridColumnPreviousDateTemp.Caption = "previous_date_billingTemp";
            this.gridColumnPreviousDateTemp.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumnPreviousDateTemp.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumnPreviousDateTemp.FieldName = "previous_date_billingTemp";
            this.gridColumnPreviousDateTemp.Name = "gridColumnPreviousDateTemp";
            this.gridColumnPreviousDateTemp.Width = 88;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "present_energy_valueTemp( Temp )";
            this.gridColumn8.DisplayFormat.FormatString = "{0:HH:mm:ss}";
            this.gridColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn8.FieldName = "present_time_updateTemp";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Width = 150;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "present_date_updateTemp";
            this.gridColumn9.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn9.FieldName = "present_date_updateTemp";
            this.gridColumn9.Name = "gridColumn9";
            // 
            // gridColumnE_MeterID
            // 
            this.gridColumnE_MeterID.Caption = "gridColumnE_MeterID";
            this.gridColumnE_MeterID.FieldName = "phone_id";
            this.gridColumnE_MeterID.Name = "gridColumnE_MeterID";
            this.gridColumnE_MeterID.Width = 62;
            // 
            // gridColumnFlag
            // 
            this.gridColumnFlag.Caption = "Flag";
            this.gridColumnFlag.FieldName = "flag_type_previous";
            this.gridColumnFlag.Name = "gridColumnFlag";
            this.gridColumnFlag.Width = 49;
            // 
            // Recording_PMeter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraScrollableControl1);
            this.Controls.Add(this.panelControl8);
            this.Controls.Add(this.groupControlPMeter);
            this.Name = "Recording_PMeter";
            this.Padding = new System.Windows.Forms.Padding(7);
            this.Size = new System.Drawing.Size(1102, 647);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl8)).EndInit();
            this.panelControl8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditBuilding.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlPMeter)).EndInit();
            this.groupControlPMeter.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.timeEditTime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditRecordDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            this.xtraScrollableControl1.ResumeLayout(false);
            this.groupBoxMeterInRoom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlPhone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewPhone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTimeEditPrevious)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTimeEditPresent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditReading)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl8;
        private DevExpress.XtraEditors.SimpleButton bttEdit;
        private DevExpress.XtraEditors.SimpleButton bttCancel;
        private DevExpress.XtraEditors.SimpleButton bttSave;
        private DevExpress.XtraEditors.SimpleButton bttReplace;
        private DevExpress.XtraEditors.LabelControl labelControlBuilding;
        private DevExpress.XtraEditors.LookUpEdit lookUpEditBuilding;
        private DevExpress.XtraEditors.GroupControl groupControlPMeter;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl1;
        private System.Windows.Forms.GroupBox groupBoxMeterInRoom;
        private DevExpress.XtraGrid.GridControl gridControlPhone;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewPhone;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnRoomName;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnMeterName;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPreviousDate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPreviousTime;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPresentDate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPresentTime;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnTotalUnit;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnReading;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditReading;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPreviousTimeTemp;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPreviousDateTemp;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnE_MeterID;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private System.Windows.Forms.GroupBox groupBox1;
        private DevExpress.XtraEditors.SimpleButton bttSet;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LookUpEdit lookUpEditRecordDate;
        private DevExpress.XtraEditors.LabelControl labelControlRecordDate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnFlag;
        private DevExpress.XtraEditors.TimeEdit timeEditTime;
        private DevExpress.XtraEditors.Repository.RepositoryItemTimeEdit repositoryItemTimeEditPrevious;
        private DevExpress.XtraEditors.Repository.RepositoryItemTimeEdit repositoryItemTimeEditPresent;
    }
}
