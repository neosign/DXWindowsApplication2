﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraEditors.Controls;

namespace DXWindowsApplication2.UserForms
{
    public partial class Recording_PMeter : uBase
    {
        double RoolBackValue = 100000; // Defualt
        double InitialValueNewEMeter = 5;
        string flagtype = "";

        List<int> rowUpdated = new List<int>();

        public Recording_PMeter()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            this.Load += new EventHandler(Recording_PMeter_Load);
            repositoryItemButtonEditReading.ButtonClick += new ButtonPressedEventHandler(repositoryItemButtonEditReading_ButtonClick);

            gridViewPhone.CustomRowCellEdit += new DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventHandler(gridViewMeterInRoom_CustomRowCellEdit);
            gridViewPhone.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(gridViewMeterInRoom_FocusedRowChanged);
            gridViewPhone.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(gridViewMeterInRoom_ValidateRow);
            gridViewPhone.InvalidRowException += new DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventHandler(gridViewMeterInRoom_InvalidRowException);
        }

        void repositoryItemButtonEditReading_ButtonClick(object sender, ButtonPressedEventArgs e)
        {
            // Read Button

            XtraMessageBox.Show("ddd");
        }

        void gridViewMeterInRoom_InvalidRowException(object sender, DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventArgs e)
        {
            e.ExceptionMode = ExceptionMode.NoAction;
        }

        void gridViewMeterInRoom_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            GridView view = sender as GridView;

            #region Previous
            GridColumn previous_date_billing = view.Columns[2];
            GridColumn previous_date_billingTemp = view.Columns[9];

            GridColumn previous_time_billing = view.Columns[3];
            GridColumn previous_time_billingTemp = view.Columns[8];

            ////Get the value of the first column
            DateTime DateTimePrevious_energy_billing = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, previous_date_billing).ToString());
            ////Get the value of the second column
            DateTime DateTimePrevious_energy_billingTemp = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, previous_date_billingTemp).ToString());

            ////Get the value of the first column
            TimeSpan TimeSpanPrevious_date_billing = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, previous_time_billing).ToString()).TimeOfDay;
            ////Get the value of the second column
            TimeSpan TimeSpanPrevious_date_billingTemp = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, previous_time_billingTemp).ToString()).TimeOfDay;

            string ErrorMSG = "";

            ////Validity criterion
            if (DateTimePrevious_energy_billing < DateTimePrevious_energy_billingTemp)
            {
                e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(previous_date_billing, "Date Time must be greater than " + DateTimePrevious_energy_billingTemp);
                ErrorMSG += "Date Time must be greater than " + DateTimePrevious_energy_billingTemp + "\r\n";
            }

            if (TimeSpanPrevious_date_billing < TimeSpanPrevious_date_billingTemp)
            {
                e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(previous_time_billing, "The value must be greater than " + TimeSpanPrevious_date_billingTemp);
                ErrorMSG += "The value must be greater than " + TimeSpanPrevious_date_billingTemp + "\r\n";
            }

            #endregion

            #region Present
            GridColumn present_date_billing = view.Columns[4];
            GridColumn present_date_billingTemp = view.Columns[11];

            GridColumn present_time_billing = view.Columns[5];
            GridColumn present_time_billingTemp = view.Columns[10];

            ////Get the value of the first column
            DateTime DateTimePresent_energy_billing = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, present_date_billing).ToString());
            ////Get the value of the second column
            DateTime DateTimePresent_energy_billingTemp = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, present_date_billingTemp).ToString());

            ////Get the value of the first column
            TimeSpan TimeSpanPresent_date_billing = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, present_time_billing).ToString()).TimeOfDay;
            ////Get the value of the second column
            TimeSpan TimeSpanPresent_date_billingTemp = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, present_time_billingTemp).ToString()).TimeOfDay;

            ////Validity criterion
            if (DateTimePresent_energy_billing < DateTimePresent_energy_billingTemp)
            {
                e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(present_date_billing, "Date Time must be greater than " + DateTimePresent_energy_billingTemp);
                ErrorMSG += "Date Time must be greater than " + DateTimePresent_energy_billingTemp + "\r\n";
            }

            if (TimeSpanPresent_date_billing < TimeSpanPresent_date_billingTemp)
            {
                e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(present_time_billing, "The value must be greater than " + TimeSpanPresent_date_billingTemp);
                ErrorMSG += "The value must be greater than " + TimeSpanPresent_date_billingTemp + "\r\n";
            }
            #endregion

            if (ErrorMSG != "")
            {
                XtraMessageBox.Show(ErrorMSG);
                return;
            }
            else if ((TimeSpanPrevious_date_billing != TimeSpanPrevious_date_billingTemp) || (DateTimePrevious_energy_billing != DateTimePrevious_energy_billingTemp) || (TimeSpanPrevious_date_billing != TimeSpanPrevious_date_billingTemp) || (DateTimePresent_energy_billing != DateTimePresent_energy_billingTemp) || (TimeSpanPresent_date_billing != TimeSpanPresent_date_billingTemp))
            {
                rowUpdated.Add(e.RowHandle);
            }


        }

        void gridViewMeterInRoom_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            int[] rowIndex = gridViewPhone.GetSelectedRows();
             try
             {
                 if (rowIndex[0] >= 0)
                 {
                     DataRow CurrentRow = gridViewPhone.GetDataRow(rowIndex[0]);
                     
                         flagtype = CurrentRow["flag_type_previous"].ToString();
                     
                 }
             } 
             catch (Exception ex)
             {
                 XtraMessageBox.Show(ex.Message.ToString());
             }

        }

        void gridViewMeterInRoom_CustomRowCellEdit(object sender, DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventArgs e)
        {
            if (e.Column.Name == "gridColumnReading")
            {
                e.RepositoryItem = repositoryItemButtonEditReading;
            }
        }

        void Recording_PMeter_Load(object sender, EventArgs e)
        {
            //insertRecordTest();
            initGroupDateDropDown();
            LoadDefaultGridInRoom();
        }
        
        void initGroupDateDropDown() {
            DataTable List_DateGroup = BusinessLogicBridge.DataStore.getGroupDateRecord();

            lookUpEditRecordDate.Properties.DisplayMember = "groupdate";
            lookUpEditRecordDate.Properties.ValueMember = "groupdate";
            lookUpEditRecordDate.Properties.DataSource = List_DateGroup;

            lookUpEditRecordDate.ItemIndex = 0;


        }
        void LoadDefaultGridInRoom()
        {

            #region Comment
            //try
            //{
            //    DataTable List_EMeter = BusinessLogicBridge.DataStore.getlistE_Meter("Exclude");
            //    DataTable List_EMeterRecord = new DataTable();

            //    List_EMeter.Columns.Add("meter_cut_text");
            //    List_EMeter.Columns.Add("E_DateTime");
            //    List_EMeter.Columns.Add("Total_Energy");
            //    List_EMeter.Columns.Add("E_CommStatus");
            //    List_EMeter.Columns.Add("total_unit", typeof(string));


            //    for (int i = 0; i < List_EMeter.Rows.Count; i++)
            //    {
            //        List_EMeter.Rows[i]["E_DateTime"] = String.Format("{0:yyyy-MM-dd}", List_EMeter.Rows[i]["present_date_update"]);
            //        List_EMeter.Rows[i]["E_CommStatus"] = List_EMeter.Rows[i]["meter_status"].ToString().Replace("communication", "").ToUpper();
                    
            //        if (List_EMeter.Rows[i]["Total_Energy"].ToString() == "") List_EMeter.Rows[i]["Total_Energy"] = 0;

            //                if (List_EMeter.Rows[i]["previous_serial"].ToString() == "")
            //                {
            //                    // Not Change Meter Serial
                                
            //                    List_EMeter.Rows[i]["total_unit"] = String.Format("{0:0.0}", (RoolBackValue + Convert.ToDouble(List_EMeter.Rows[i]["Total_Energy"].ToString())) - Convert.ToDouble(List_EMeter.Rows[i]["previous_energy_billing"].ToString()));
            //                }
            //                else {

            //                    List_EMeterRecord = BusinessLogicBridge.DataStore.getlistE_MeterRecord(List_EMeter.Rows[i]["previous_serial"].ToString());

            //                    // Present Energy < Previous Energy right ?
            //                    if (Convert.ToDouble(List_EMeter.Rows[i]["present_energy_value"].ToString()) < Convert.ToDouble(List_EMeter.Rows[i]["previous_energy_billing"].ToString()))
            //                    {
            //                        List_EMeter.Rows[i]["total_unit"] = String.Format("{0:0.0}", (Convert.ToDouble(List_EMeter.Rows[i]["present_energy_value"].ToString()) - InitialValueNewEMeter) + (Convert.ToDouble(List_EMeterRecord.Rows[0]["Total_Energy"].ToString()) - Convert.ToDouble(List_EMeter.Rows[i]["previous_energy_billing"].ToString())));
            //                    }
            //                    else {
            //                        List_EMeter.Rows[i]["total_unit"] = String.Format("{0:0.0}", (Convert.ToDouble(List_EMeter.Rows[i]["present_energy_value"].ToString())) - Convert.ToDouble(List_EMeter.Rows[i]["previous_energy_billing"].ToString()));
            //                    }      
            //                }


            //                if (List_EMeter.Rows[i]["meter_cut"].ToString() == "False")
            //                {
            //                    List_EMeter.Rows[i]["meter_cut_text"] = "Open";
            //                }
            //                else
            //                {
            //                    List_EMeter.Rows[i]["meter_cut_text"] = "Closed";
            //                }
            //    }

            //    gridControlMeterInRoom.DataSource = List_EMeter;
            //}
            //catch (Exception ex)
            //{
            //    throw new Exception(ex.ToString(), ex);
            //}
            #endregion

            #region Meter in Room

            string date = String.Format("{0:yyyy-MM-dd}", Convert.ToDateTime(lookUpEditRecordDate.EditValue));
            string time = String.Format("{0:HH:mm:ss}", timeEditTime.EditValue);

            DataTable RecordBySerial = BusinessLogicBridge.DataStore.ReadPhoneRecordingByDate();

            RecordBySerial.Columns.Add("flag_type_previous");
            RecordBySerial.Columns.Add("previous_time_billing_x", typeof(DateTime));
            RecordBySerial.Columns.Add("p_end_time_x", typeof(DateTime));
            RecordBySerial.Columns.Add("previous_date_billingTemp");
            RecordBySerial.Columns.Add("previous_time_billingTemp");
            RecordBySerial.Columns.Add("present_date_updateTemp");            
            RecordBySerial.Columns.Add("present_time_updateTemp");

            DataTable CheckinInfo = new DataTable("CheckinInfo");

            for (int i = 0; i < RecordBySerial.Rows.Count; i++)
            {

                RecordBySerial.Rows[i]["previous_time_billing_x"] = RecordBySerial.Rows[i]["previous_time_billing"];
                
                RecordBySerial.Rows[i]["previous_date_billingTemp"] = RecordBySerial.Rows[i]["previous_date_billing"];
                RecordBySerial.Rows[i]["previous_time_billingTemp"] = RecordBySerial.Rows[i]["previous_time_billing_x"];


                RecordBySerial.Rows[i]["p_end_time_x"] = RecordBySerial.Rows[i]["p_end_time"];

                RecordBySerial.Rows[i]["present_date_updateTemp"] = RecordBySerial.Rows[i]["p_end_date"];
                RecordBySerial.Rows[i]["present_time_updateTemp"] = RecordBySerial.Rows[i]["p_end_time_x"];


                if (RecordBySerial.Rows[i]["p_end_date"].ToString() == "" && RecordBySerial.Rows[i]["p_end_time"].ToString() == "")
                {
                    RecordBySerial.Rows[i]["present_date_updateTemp"] = String.Format("{0:yyyy-MM-dd}",DateTime.Now);
                    RecordBySerial.Rows[i]["present_time_updateTemp"] = String.Format("{0:HH:mm:ss}",DateTime.Now);

                    RecordBySerial.Rows[i]["p_end_date"] = String.Format("{0:yyyy-MM-dd}",DateTime.Now);
                    RecordBySerial.Rows[i]["p_end_time_x"] = DateTime.Now;

                }
                else
                {
                    RecordBySerial.Rows[i]["present_date_updateTemp"] = RecordBySerial.Rows[i]["p_end_date"];
                    RecordBySerial.Rows[i]["present_time_updateTemp"] = RecordBySerial.Rows[i]["p_end_time"];


                    RecordBySerial.Rows[i]["p_end_date"] = String.Format("{0:yyyy-MM-dd}", RecordBySerial.Rows[i]["p_end_date"]);
                    RecordBySerial.Rows[i]["p_end_time_x"] = Convert.ToDateTime(RecordBySerial.Rows[i]["p_end_time"].ToString());

                }

                if (RecordBySerial.Rows[i]["previous_date_billing"].ToString() == "")
                {
                    //check_in_electricit_date 	check_in_electricitymeter 	check_in_watermeter 	check_in_water_date 

                    CheckinInfo = BusinessLogicBridge.DataStore.ReadStartMeterByRoomIDFromCheckIn(RecordBySerial.Rows[i]["room_id"].ToString());

                    if (CheckinInfo.Rows.Count > 0)
                    {
                        RecordBySerial.Rows[i]["flag_type_previous"] = "fromcheckin";
                        RecordBySerial.Rows[i]["previous_date_billing"] = String.Format("{0:yyyy-MM-dd}", CheckinInfo.Rows[0]["check_in_phone_date"]);
                        RecordBySerial.Rows[i]["previous_time_billing_x"] = Convert.ToDateTime(CheckinInfo.Rows[0]["check_in_phone_date"].ToString());

                        // Clone to Temp
                        RecordBySerial.Rows[i]["previous_date_billingTemp"] = String.Format("{0:yyyy-MM-dd}",RecordBySerial.Rows[i]["previous_date_billing"]);
                        RecordBySerial.Rows[i]["previous_time_billingTemp"] = String.Format("{0:HH:mm:ss}", RecordBySerial.Rows[i]["previous_time_billing_x"]);

                    }

                }
                
            }

            gridControlPhone.DataSource = RecordBySerial;
            #endregion

        }

        private void setEnable()
        {
            bttSave.Enabled = true;
            bttCancel.Enabled = true;

            bttEdit.Enabled = false;

        }

        private void setDisable()
        {
            bttSave.Enabled = false;
            bttCancel.Enabled = false;

            bttEdit.Enabled = true;

        }

        private void bttEdit_Click(object sender, EventArgs e)
        {
            gridViewPhone.Columns[2].OptionsColumn.AllowEdit = true;
            gridViewPhone.Columns[3].OptionsColumn.AllowEdit = true;

            gridViewPhone.Columns[4].OptionsColumn.AllowEdit = true;
            gridViewPhone.Columns[5].OptionsColumn.AllowEdit = true;

            setEnable();

        }

        private void bttSave_Click(object sender, EventArgs e)
        {

            DataRow UpdateRow;

            for (int i = 0; i < rowUpdated.Count; i++) {

                UpdateRow = gridViewPhone.GetDataRow(rowUpdated[i]);

                switch (UpdateRow["flag_type_previous"].ToString()) {

                    case "frombilling":
                        
                        // Must Cancel on Old Billing
                        // And Create new Billing Trasaction
                        BusinessLogicBridge.DataStore.cancelCreateNewBillingTransaction(UpdateRow);
                        break;
                    case "fromcheckin":

                        // Must Cancel on Old Checkin
                        // And Create new Checkin Trasaction
                        BusinessLogicBridge.DataStore.cancelCreateNewCheckInTransaction(UpdateRow);
                        break;
                    default :
                        break;

                }
            }

            //RecordBySerialTemp.GetChanges(DataRowState);
            
            setDisable();

            //if (flagtype == "frombilling") { 
                
            //}
        }
    }
}
