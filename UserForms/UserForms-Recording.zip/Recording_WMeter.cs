﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraEditors.Controls;

namespace DXWindowsApplication2.UserForms
{
    public partial class Recording_WMeter : uBase
    {
        double RoolBackValue = 100000; // Defualt
        double InitialValueNewEMeter = 5;
        string flagtype = "";

        List<int> rowUpdated = new List<int>();

        public Recording_WMeter()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            this.Load += new EventHandler(Recording_EMeter_Load);
            repositoryItemButtonEditReading.ButtonClick += new ButtonPressedEventHandler(repositoryItemButtonEditReading_ButtonClick);

            gridViewMeterInRoom.CustomRowCellEdit += new DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventHandler(gridViewMeterInRoom_CustomRowCellEdit);
            gridViewMeterInRoom.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(gridViewMeterInRoom_FocusedRowChanged);
            gridViewMeterInRoom.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(gridViewMeterInRoom_ValidateRow);
            gridViewMeterInRoom.InvalidRowException += new DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventHandler(gridViewMeterInRoom_InvalidRowException);
        }

        void repositoryItemButtonEditReading_ButtonClick(object sender, ButtonPressedEventArgs e)
        {
            // Read Button

           // XtraMessageBox.Show("ddd");
        }

        void gridViewMeterInRoom_InvalidRowException(object sender, DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventArgs e)
        {
            e.ExceptionMode = ExceptionMode.NoAction;
        }

        void gridViewMeterInRoom_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            GridView view = sender as GridView;

            #region Previous
            GridColumn previous_energy_billing = view.Columns[3];
            GridColumn previous_energy_billingTemp = view.Columns[10];

            GridColumn previous_date_billing = view.Columns[2];
            GridColumn previous_date_billingTemp = view.Columns[11];

            //Get the value of the first column
            Decimal DoublePrevious_energy_billing = Convert.ToDecimal(view.GetRowCellValue(e.RowHandle, previous_energy_billing).ToString());
            //Get the value of the second column
            Decimal DoublePrevious_energy_billingTemp = Convert.ToDecimal(view.GetRowCellValue(e.RowHandle, previous_energy_billingTemp).ToString());

            //Get the value of the first column
            DateTime DoublePrevious_date_billing = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, previous_date_billing).ToString());
            //Get the value of the second column
            DateTime DoublePrevious_date_billingTemp = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, previous_date_billingTemp).ToString());

            string ErrorMSG = "";

            //Validity criterion
            if (DoublePrevious_date_billing < DoublePrevious_date_billingTemp)
            {
                e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(previous_date_billing, "Date Time must be greater than " + DoublePrevious_date_billingTemp);
                ErrorMSG += "Date Time must be greater than " + DoublePrevious_date_billingTemp + "\r\n";
            }

            if (DoublePrevious_energy_billing < DoublePrevious_energy_billingTemp)
            {
                 e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(previous_energy_billing, "The value must be greater than " + DoublePrevious_energy_billingTemp);
                ErrorMSG += "The value must be greater than " + DoublePrevious_energy_billingTemp + "\r\n";
            }

            #endregion
            #region Present
            GridColumn present_energy_billing = view.Columns[5];
            GridColumn present_energy_billingTemp = view.Columns[13];

            GridColumn present_date_billing = view.Columns[4];
            GridColumn present_date_billingTemp = view.Columns[14];

            //Get the value of the first column
            Decimal DoublePresent_energy_billing = Convert.ToDecimal(view.GetRowCellValue(e.RowHandle, present_energy_billing).ToString());
            //Get the value of the second column
            Decimal DoublePresent_energy_billingTemp = Convert.ToDecimal(view.GetRowCellValue(e.RowHandle, present_energy_billingTemp).ToString());

            if (view.GetRowCellValue(e.RowHandle, present_date_billing).ToString() == "")
            {
                e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(present_date_billing, "Please select present time recording...");
                ErrorMSG += "Please select present time recording...\r\n";
                utilClass.showPopupMessegeBox(this, ErrorMSG, "Warning");
                return;
            }

            //Get the value of the first column
            DateTime DoublePresent_date_billing = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, present_date_billing).ToString());
            //Get the value of the second column
            DateTime DoublePresent_date_billingTemp = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, present_date_billingTemp).ToString());

            //Validity criterion
            if (DoublePresent_date_billing < DoublePresent_date_billingTemp)
            {
                e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(present_date_billing, "Date Time must be greater than " + DoublePresent_date_billingTemp);
                ErrorMSG += "Date Time must be greater than " + DoublePresent_date_billingTemp + "\r\n";
            }

            if (DoublePresent_energy_billing < DoublePresent_energy_billingTemp)
            {
                e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(present_energy_billing, "The value must be greater than " + DoublePresent_energy_billingTemp);
                ErrorMSG += "The value must be greater than " + DoublePresent_energy_billingTemp + "\r\n";
            }

            #endregion

            if (ErrorMSG != "")
            {
                utilClass.showPopupMessegeBox(this, ErrorMSG, "Warning");
                return;
            }
            else if ((DoublePrevious_energy_billing != DoublePrevious_energy_billingTemp) || (DoublePrevious_date_billing != DoublePrevious_date_billingTemp) || (DoublePresent_energy_billing != DoublePresent_energy_billingTemp) || (DoublePresent_date_billing != DoublePresent_date_billingTemp))
            {
                rowUpdated.Add(e.RowHandle);
            }



        }

        void gridViewMeterInRoom_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            int[] rowIndex = gridViewMeterInRoom.GetSelectedRows();
             try
             {
                 if (rowIndex[0] >= 0)
                 {
                     DataRow CurrentRow = gridViewMeterInRoom.GetDataRow(rowIndex[0]);
                     
                         flagtype = CurrentRow["flag_type_previous"].ToString();
                     
                 }
             } 
             catch (Exception ex)
             {
                 XtraMessageBox.Show(ex.Message.ToString());
             }

        }

        void gridViewMeterInRoom_CustomRowCellEdit(object sender, DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventArgs e)
        {
            if (e.Column.Name == "gridColumnReading")
            {
                e.RepositoryItem = repositoryItemButtonEditReading;
            }
        }

        void Recording_EMeter_Load(object sender, EventArgs e)
        {
            initGroupDateDropDown();
            LoadDefaultGridInRoom();
        }
        
        void initGroupDateDropDown() {
            DataTable List_DateGroup = BusinessLogicBridge.DataStore.getGroupDateWaterRecord();

            lookUpEditRecordDate.Properties.DisplayMember = "groupdate";
            lookUpEditRecordDate.Properties.ValueMember = "groupdate";
            lookUpEditRecordDate.Properties.DataSource = List_DateGroup;

            lookUpEditRecordDate.ItemIndex = 0;


        }
        void LoadDefaultGridInRoom()
        {

            #region Comment
            //try
            //{
            //    DataTable List_EMeter = BusinessLogicBridge.DataStore.getlistE_Meter("Exclude");
            //    DataTable List_EMeterRecord = new DataTable();

            //    List_EMeter.Columns.Add("meter_cut_text");
            //    List_EMeter.Columns.Add("E_DateTime");
            //    List_EMeter.Columns.Add("Total_Energy");
            //    List_EMeter.Columns.Add("E_CommStatus");
            //    List_EMeter.Columns.Add("total_unit", typeof(string));


            //    for (int i = 0; i < List_EMeter.Rows.Count; i++)
            //    {
            //        List_EMeter.Rows[i]["E_DateTime"] = String.Format("{0:yyyy-MM-dd}", List_EMeter.Rows[i]["present_date_update"]);
            //        List_EMeter.Rows[i]["E_CommStatus"] = List_EMeter.Rows[i]["meter_status"].ToString().Replace("communication", "").ToUpper();
                    
            //        if (List_EMeter.Rows[i]["Total_Energy"].ToString() == "") List_EMeter.Rows[i]["Total_Energy"] = 0;

            //                if (List_EMeter.Rows[i]["previous_serial"].ToString() == "")
            //                {
            //                    // Not Change Meter Serial
                                
            //                    List_EMeter.Rows[i]["total_unit"] = String.Format("{0:0.0}", (RoolBackValue + Convert.ToDouble(List_EMeter.Rows[i]["Total_Energy"].ToString())) - Convert.ToDouble(List_EMeter.Rows[i]["previous_energy_billing"].ToString()));
            //                }
            //                else {

            //                    List_EMeterRecord = BusinessLogicBridge.DataStore.getlistE_MeterRecord(List_EMeter.Rows[i]["previous_serial"].ToString());

            //                    // Present Energy < Previous Energy right ?
            //                    if (Convert.ToDouble(List_EMeter.Rows[i]["present_energy_value"].ToString()) < Convert.ToDouble(List_EMeter.Rows[i]["previous_energy_billing"].ToString()))
            //                    {
            //                        List_EMeter.Rows[i]["total_unit"] = String.Format("{0:0.0}", (Convert.ToDouble(List_EMeter.Rows[i]["present_energy_value"].ToString()) - InitialValueNewEMeter) + (Convert.ToDouble(List_EMeterRecord.Rows[0]["Total_Energy"].ToString()) - Convert.ToDouble(List_EMeter.Rows[i]["previous_energy_billing"].ToString())));
            //                    }
            //                    else {
            //                        List_EMeter.Rows[i]["total_unit"] = String.Format("{0:0.0}", (Convert.ToDouble(List_EMeter.Rows[i]["present_energy_value"].ToString())) - Convert.ToDouble(List_EMeter.Rows[i]["previous_energy_billing"].ToString()));
            //                    }      
            //                }


            //                if (List_EMeter.Rows[i]["meter_cut"].ToString() == "False")
            //                {
            //                    List_EMeter.Rows[i]["meter_cut_text"] = "Open";
            //                }
            //                else
            //                {
            //                    List_EMeter.Rows[i]["meter_cut_text"] = "Closed";
            //                }
            //    }

            //    gridControlMeterInRoom.DataSource = List_EMeter;
            //}
            //catch (Exception ex)
            //{
            //    throw new Exception(ex.ToString(), ex);
            //}
            #endregion

            string datetime = "";
            if (lookUpEditRecordDate.EditValue == null)
            {
                datetime = String.Format("{0:yyyy-MM-dd}", DateTime.Now);
            }
            else
            {
                datetime = String.Format("{0:yyyy-MM-dd}", Convert.ToDateTime(lookUpEditRecordDate.EditValue.ToString()));
            }


            /*
            #region Meter in Room
            DataTable RecordBySerial = BusinessLogicBridge.DataStore.ReadWaterRecordingByDate(datetime);

            DataTable CheckinInfo = new DataTable("CheckinInfo");

            RecordBySerial.Columns.Add("total_unit", typeof(double));
            RecordBySerial.Columns.Add("flag_type_previous", typeof(string));
            RecordBySerial.Columns.Add("previous_energy_billingTemp");
            RecordBySerial.Columns.Add("previous_date_billingTemp");
            RecordBySerial.Columns.Add("present_energy_valueTemp");
            RecordBySerial.Columns.Add("present_date_updateTemp");
            RecordBySerial.Columns.Add("E_CommStatus");

            for (int i = 0; i < RecordBySerial.Rows.Count; i++)
            {

                RecordBySerial.Rows[i]["previous_energy_billingTemp"] = RecordBySerial.Rows[i]["wprevious_energy_billing"];
                RecordBySerial.Rows[i]["previous_date_billingTemp"] = RecordBySerial.Rows[i]["wprevious_date_billing"];

                RecordBySerial.Rows[i]["present_energy_valueTemp"] = RecordBySerial.Rows[i]["wpresent_energy_value"];
                RecordBySerial.Rows[i]["present_date_updateTemp"] = RecordBySerial.Rows[i]["wpresent_date_update"];

                if (RecordBySerial.Rows[i]["wprevious_date_billing"].ToString() == "")
                {
                    //check_in_electricit_date 	check_in_electricitymeter 	check_in_watermeter 	check_in_water_date 

                    CheckinInfo = BusinessLogicBridge.DataStore.ReadStartMeterByRoomIDFromCheckIn(RecordBySerial.Rows[i]["room_id"].ToString());

                    if (CheckinInfo.Rows.Count > 0)
                    {
                        RecordBySerial.Rows[i]["flag_type_previous"] = "fromcheckin";
                        RecordBySerial.Rows[i]["wprevious_date_billing"] = CheckinInfo.Rows[0]["check_in_electricit_date"];
                        RecordBySerial.Rows[i]["wprevious_energy_billing"] = CheckinInfo.Rows[0]["check_in_electricitymeter"];

                        // Clone to Temp
                        RecordBySerial.Rows[i]["previous_energy_billingTemp"] = RecordBySerial.Rows[i]["wprevious_energy_billing"];
                        RecordBySerial.Rows[i]["previous_date_billingTemp"] = RecordBySerial.Rows[i]["wprevious_date_billing"];

                    }

                }
                else
                {
                    RecordBySerial.Rows[i]["flag_type_previous"] = "frombilling";
                }

                if (RecordBySerial.Rows[i]["meter_status"].To<bool>()==false)
                {

                    RecordBySerial.Rows[i]["E_CommStatus"] = "FAIL";

                }
                else
                {

                    RecordBySerial.Rows[i]["E_CommStatus"] = "PASS";
                }

                RecordBySerial.Rows[i]["total_unit"] = RecordBySerial.Rows[0]["wpresent_energy_value"].To<double>() - RecordBySerial.Rows[i]["wprevious_energy_billing"].To<double>();

            }
            gridControlMeterInRoom.DataSource = RecordBySerial;
            #endregion
            */
            #region Meter in Room
            DataTable RecordBySerial = BusinessLogicBridge.DataStore.ReadWaterRecordingByDate(datetime);

            DataTable CheckinInfo = new DataTable("CheckinInfo");

            RecordBySerial.Columns.Add("total_unit", typeof(string));
            RecordBySerial.Columns.Add("flag_type_previous", typeof(string));
            RecordBySerial.Columns.Add("previous_energy_billingTemp", typeof(double));
            RecordBySerial.Columns.Add("previous_date_billingTemp");
            RecordBySerial.Columns.Add("present_energy_valueTemp", typeof(double));
            RecordBySerial.Columns.Add("present_date_updateTemp");
            RecordBySerial.Columns.Add("E_CommStatus");
            
            for (int i = 0; i < RecordBySerial.Rows.Count; i++)
            {

                RecordBySerial.Rows[i]["previous_energy_billingTemp"] = RecordBySerial.Rows[i]["wprevious_energy_billing"];
                if (RecordBySerial.Rows[i]["wprevious_date_billing"].ToString() == "")
                {
                    RecordBySerial.Rows[i]["wprevious_date_billing"] = DateTime.Now;
                }

                RecordBySerial.Rows[i]["previous_date_billingTemp"] = RecordBySerial.Rows[i]["wprevious_date_billing"];

                RecordBySerial.Rows[i]["present_energy_valueTemp"] = RecordBySerial.Rows[i]["wpresent_energy_value"];
                if (RecordBySerial.Rows[i]["wpresent_date_update"].ToString() == "")
                {
                    RecordBySerial.Rows[i]["present_date_updateTemp"] = DateTime.Now;
                }
                else
                {
                    RecordBySerial.Rows[i]["present_date_updateTemp"] = RecordBySerial.Rows[i]["wpresent_date_update"];
                }

                if (RecordBySerial.Rows[i]["wprevious_date_billing"].ToString() == "")
                {
                    //check_in_electricit_date 	check_in_electricitymeter 	check_in_watermeter 	check_in_water_date 

                    CheckinInfo = BusinessLogicBridge.DataStore.ReadStartMeterByRoomIDFromCheckIn(RecordBySerial.Rows[i]["room_id"].ToString());

                    if (CheckinInfo.Rows.Count > 0)
                    {
                        RecordBySerial.Rows[i]["flag_type_previous"] = "fromcheckin";
                        RecordBySerial.Rows[i]["wprevious_date_billing"] = CheckinInfo.Rows[0]["check_in_water_date"];
                        RecordBySerial.Rows[i]["wprevious_energy_billing"] = CheckinInfo.Rows[0]["check_in_watermeter"];

                        // Clone to Temp
                        RecordBySerial.Rows[i]["previous_energy_billingTemp"] = RecordBySerial.Rows[i]["wprevious_energy_billing"];
                        RecordBySerial.Rows[i]["previous_date_billingTemp"] = RecordBySerial.Rows[i]["wprevious_date_billing"];
                    }

                }
                else
                {
                    RecordBySerial.Rows[i]["flag_type_previous"] = "frombilling";
                }

                if (RecordBySerial.Rows[i]["water_status"].To<int>() == 0)
                {

                    RecordBySerial.Rows[i]["E_CommStatus"] = "FAIL";

                }
                else
                {

                    RecordBySerial.Rows[i]["E_CommStatus"] = "PASS";
                }
            }



            gridControlMeterInRoom.DataSource = RecordBySerial;
            #endregion
        }

        private void setEnable()
        {
            bttSave.Enabled = true;
            bttCancel.Enabled = true;

            bttEdit.Enabled = false;

        }

        private void setDisable()
        {
            bttSave.Enabled = false;
            bttCancel.Enabled = false;

            bttEdit.Enabled = true;

        }

        private void bttEdit_Click(object sender, EventArgs e)
        {
            gridViewMeterInRoom.Columns[3].OptionsColumn.AllowEdit = true;
            gridViewMeterInRoom.Columns[4].OptionsColumn.AllowEdit = true;

            gridViewMeterInRoom.Columns[5].OptionsColumn.AllowEdit = true;
            gridViewMeterInRoom.Columns[6].OptionsColumn.AllowEdit = true;

            setEnable();

        }

        private void bttSave_Click(object sender, EventArgs e)
        {

            DataRow UpdateRow;

            for (int i = 0; i < rowUpdated.Count; i++)
            {

                UpdateRow = gridViewMeterInRoom.GetDataRow(rowUpdated[i]);
                // Insert Transaction Water meter
                BusinessLogicBridge.DataStore.insertW_Record(UpdateRow);
            } 
            
            setDisable();
        }
    }
}
