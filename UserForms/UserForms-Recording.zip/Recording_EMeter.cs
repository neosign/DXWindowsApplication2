﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraEditors.Controls;

namespace DXWindowsApplication2.UserForms
{
    public partial class Recording_EMeter : uBase
    {
        double RoolBackValue = 100000; // Defualt
        double InitialValueNewEMeter = 5;
        string flagtype = "";

        List<int> rowUpdated = new List<int>();

        public Recording_EMeter()
        {
            InitializeComponent();
            this.Dock = DockStyle.Fill;
            this.Load += new EventHandler(Recording_EMeter_Load);
            repositoryItemButtonEditReading.ButtonClick += new ButtonPressedEventHandler(repositoryItemButtonEditReading_ButtonClick);

            gridViewMeterInRoom.CustomRowCellEdit += new DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventHandler(gridViewMeterInRoom_CustomRowCellEdit);
            gridViewMeterInRoom.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(gridViewMeterInRoom_FocusedRowChanged);
            gridViewMeterInRoom.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(gridViewMeterInRoom_ValidateRow);
            gridViewMeterInRoom.InvalidRowException += new DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventHandler(gridViewMeterInRoom_InvalidRowException);
        }

        void repositoryItemButtonEditReading_ButtonClick(object sender, ButtonPressedEventArgs e)
        {
            // Read Button

            DataRow currentRow = gridViewMeterInRoom.GetDataRow(gridViewMeterInRoom.FocusedRowHandle);

            string MeterSerial = currentRow["meter_serial"].ToString();

            DXWindowsApplication2.MainForm.dictADC["adc_id_" + currentRow["device_adc_id"]].GetEMeterLastTransaction(MeterSerial);

        }

        void gridViewMeterInRoom_InvalidRowException(object sender, DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventArgs e)
        {
            e.ExceptionMode = ExceptionMode.NoAction;
        }

        void gridViewMeterInRoom_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            GridView view = sender as GridView;

            #region Previous
            GridColumn previous_energy_billing = view.Columns[4];
            GridColumn previous_energy_billingTemp = view.Columns[12];

            GridColumn previous_date_billing = view.Columns[3];
            GridColumn previous_date_billingTemp = view.Columns[13];

            //Get the value of the first column
            Decimal DoublePrevious_energy_billing = Convert.ToDecimal(view.GetRowCellValue(e.RowHandle, previous_energy_billing).ToString());
            //Get the value of the second column
            Decimal DoublePrevious_energy_billingTemp = Convert.ToDecimal(view.GetRowCellValue(e.RowHandle, previous_energy_billingTemp).ToString());

            //Get the value of the first column
            DateTime DoublePrevious_date_billing = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, previous_date_billing).ToString());
            //Get the value of the second column
            DateTime DoublePrevious_date_billingTemp = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, previous_date_billingTemp).ToString());

            string ErrorMSG = "";

            //Validity criterion
            if (DoublePrevious_date_billing < DoublePrevious_date_billingTemp)
            {
                e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(previous_date_billing, "Date Time must be greater than " + DoublePrevious_date_billingTemp);
                ErrorMSG += "Date Time must be greater than " + DoublePrevious_date_billingTemp + "\r\n";
            }

            if (DoublePrevious_energy_billing < DoublePrevious_energy_billingTemp)
            {
                 e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(previous_energy_billing, "The value must be greater than " + DoublePrevious_energy_billingTemp);
                ErrorMSG += "The value must be greater than " + DoublePrevious_energy_billingTemp + "\r\n";
            }

            #endregion
            #region Present
            GridColumn present_energy_billing = view.Columns[6];
            GridColumn present_energy_billingTemp = view.Columns[15];

            GridColumn present_date_billing = view.Columns[5];
            GridColumn present_date_billingTemp = view.Columns[16];

            //Get the value of the first column
            Decimal DoublePresent_energy_billing = Convert.ToDecimal(view.GetRowCellValue(e.RowHandle, present_energy_billing).ToString());
            //Get the value of the second column
            Decimal DoublePresent_energy_billingTemp = Convert.ToDecimal(view.GetRowCellValue(e.RowHandle, present_energy_billingTemp).ToString());

            //Get the value of the first column
            if (view.GetRowCellValue(e.RowHandle, present_date_billing).ToString() == "")
            {
                e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(present_date_billing, "Please select present time recording...");
                ErrorMSG += "Please select present time recording...\r\n";
                utilClass.showPopupMessegeBox(this, ErrorMSG, "Warning");
                return;
            }

                DateTime DoublePresent_date_billing = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, present_date_billing).ToString());
                //Get the value of the second column
                DateTime DoublePresent_date_billingTemp = Convert.ToDateTime(view.GetRowCellValue(e.RowHandle, present_date_billingTemp).ToString());
            
            
            //Validity criterion
            if (DoublePresent_date_billing < DoublePresent_date_billingTemp)
            {
                e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(present_date_billing, "Date Time must be greater than " + DoublePresent_date_billingTemp);
                ErrorMSG += "Date Time must be greater than " + DoublePresent_date_billingTemp + "\r\n";
            }

            if (DoublePresent_energy_billing < DoublePresent_energy_billingTemp)
            {
                e.Valid = false;
                //Set errors with specific descriptions for the columns
                view.SetColumnError(present_energy_billing, "The value must be greater than " + DoublePresent_energy_billingTemp);
                ErrorMSG += "The value must be greater than " + DoublePresent_energy_billingTemp + "\r\n";
            }

            #endregion

            if (ErrorMSG != "")
            {
                utilClass.showPopupMessegeBox(this, ErrorMSG, "Warning");
                return;
            }
            else if ((DoublePrevious_energy_billing != DoublePrevious_energy_billingTemp) || (DoublePrevious_date_billing != DoublePrevious_date_billingTemp) || (DoublePresent_energy_billing != DoublePresent_energy_billingTemp) || (DoublePresent_date_billing != DoublePresent_date_billingTemp))
            {
                rowUpdated.Add(e.RowHandle);
            }



        }

        void gridViewMeterInRoom_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            int[] rowIndex = gridViewMeterInRoom.GetSelectedRows();
             try
             {
                 if (rowIndex[0] >= 0)
                 {
                     DataRow CurrentRow = gridViewMeterInRoom.GetDataRow(rowIndex[0]);
                     
                         flagtype = CurrentRow["flag_type_previous"].ToString();
                     
                 }
             } 
             catch (Exception ex)
             {
                 XtraMessageBox.Show(ex.Message.ToString());
             }

        }

        void gridViewMeterInRoom_CustomRowCellEdit(object sender, DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventArgs e)
        {
            if (e.Column.Name == "gridColumnReading")
            {
                e.RepositoryItem = repositoryItemButtonEditReading;
            }
        }

        void Recording_EMeter_Load(object sender, EventArgs e)
        {
            //insertRecordTest();
            initGroupDateDropDown();
            LoadDefaultGridInRoom();
        }

        void insertRecordTest(){

            DataTable RecordFromAPI = new DataTable();
            

            RecordFromAPI = DXWindowsApplication2.MainForm.dictADC["adc_id_1"].GetAllEMeterTransactionDT();

            RecordFromAPI.Columns.Add("device_adc_id", typeof(int));
            for (int i = 0; i < RecordFromAPI.Rows.Count; i++)
            {
                RecordFromAPI.Rows[i]["device_adc_id"] = 1;
            }

            BusinessLogicBridge.DataStore.insertE_RecordToMysql(RecordFromAPI);
        }
        void initGroupDateDropDown() {
            DataTable List_DateGroup = BusinessLogicBridge.DataStore.getGroupDateRecord();

            lookUpEditRecordDate.Properties.DisplayMember = "groupdate";
            lookUpEditRecordDate.Properties.ValueMember = "groupdate";
            lookUpEditRecordDate.Properties.DataSource = List_DateGroup;

            lookUpEditRecordDate.ItemIndex = 0;


        }
        void LoadDefaultGridInRoom()
        {

            #region Comment
            //try
            //{
            //    DataTable List_EMeter = BusinessLogicBridge.DataStore.getlistE_Meter("Exclude");
            //    DataTable List_EMeterRecord = new DataTable();

            //    List_EMeter.Columns.Add("meter_cut_text");
            //    List_EMeter.Columns.Add("E_DateTime");
            //    List_EMeter.Columns.Add("Total_Energy");
            //    List_EMeter.Columns.Add("E_CommStatus");
            //    List_EMeter.Columns.Add("total_unit", typeof(string));


            //    for (int i = 0; i < List_EMeter.Rows.Count; i++)
            //    {
            //        List_EMeter.Rows[i]["E_DateTime"] = String.Format("{0:yyyy-MM-dd}", List_EMeter.Rows[i]["present_date_update"]);
            //        List_EMeter.Rows[i]["E_CommStatus"] = List_EMeter.Rows[i]["meter_status"].ToString().Replace("communication", "").ToUpper();
                    
            //        if (List_EMeter.Rows[i]["Total_Energy"].ToString() == "") List_EMeter.Rows[i]["Total_Energy"] = 0;

            //                if (List_EMeter.Rows[i]["previous_serial"].ToString() == "")
            //                {
            //                    // Not Change Meter Serial
                                
            //                    List_EMeter.Rows[i]["total_unit"] = String.Format("{0:0.0}", (RoolBackValue + Convert.ToDouble(List_EMeter.Rows[i]["Total_Energy"].ToString())) - Convert.ToDouble(List_EMeter.Rows[i]["previous_energy_billing"].ToString()));
            //                }
            //                else {

            //                    List_EMeterRecord = BusinessLogicBridge.DataStore.getlistE_MeterRecord(List_EMeter.Rows[i]["previous_serial"].ToString());

            //                    // Present Energy < Previous Energy right ?
            //                    if (Convert.ToDouble(List_EMeter.Rows[i]["present_energy_value"].ToString()) < Convert.ToDouble(List_EMeter.Rows[i]["previous_energy_billing"].ToString()))
            //                    {
            //                        List_EMeter.Rows[i]["total_unit"] = String.Format("{0:0.0}", (Convert.ToDouble(List_EMeter.Rows[i]["present_energy_value"].ToString()) - InitialValueNewEMeter) + (Convert.ToDouble(List_EMeterRecord.Rows[0]["Total_Energy"].ToString()) - Convert.ToDouble(List_EMeter.Rows[i]["previous_energy_billing"].ToString())));
            //                    }
            //                    else {
            //                        List_EMeter.Rows[i]["total_unit"] = String.Format("{0:0.0}", (Convert.ToDouble(List_EMeter.Rows[i]["present_energy_value"].ToString())) - Convert.ToDouble(List_EMeter.Rows[i]["previous_energy_billing"].ToString()));
            //                    }      
            //                }


            //                if (List_EMeter.Rows[i]["meter_cut"].ToString() == "False")
            //                {
            //                    List_EMeter.Rows[i]["meter_cut_text"] = "Open";
            //                }
            //                else
            //                {
            //                    List_EMeter.Rows[i]["meter_cut_text"] = "Closed";
            //                }
            //    }

            //    gridControlMeterInRoom.DataSource = List_EMeter;
            //}
            //catch (Exception ex)
            //{
            //    throw new Exception(ex.ToString(), ex);
            //}
            #endregion

            string datetime = "";
            if (lookUpEditRecordDate.EditValue == null)
            {
                datetime = String.Format("{0:yyyy-MM-dd}", DateTime.Now);
            }
            else
            {
                datetime = String.Format("{0:yyyy-MM-dd}", Convert.ToDateTime(lookUpEditRecordDate.EditValue.ToString()));
            }

            #region Meter in Room
            DataTable RecordBySerial = BusinessLogicBridge.DataStore.ReadRecordingByDate(datetime);

            DataTable CheckinInfo = new DataTable("CheckinInfo");

            RecordBySerial.Columns.Add("total_unit", typeof(string));
            RecordBySerial.Columns.Add("flag_type_previous", typeof(string));
            RecordBySerial.Columns.Add("previous_energy_billingTemp", typeof(double));
            RecordBySerial.Columns.Add("previous_date_billingTemp");
            RecordBySerial.Columns.Add("present_energy_valueTemp", typeof(double));
            RecordBySerial.Columns.Add("present_date_updateTemp");
            RecordBySerial.Columns.Add("E_CommStatus");
            RecordBySerial.Columns.Add("meter_cut_text");

            for (int i = 0; i < RecordBySerial.Rows.Count; i++)
            {

                RecordBySerial.Rows[i]["previous_energy_billingTemp"] = RecordBySerial.Rows[i]["previous_energy_billing"];
                
                if (RecordBySerial.Rows[i]["previous_date_billing"].ToString() == "") {
                    RecordBySerial.Rows[i]["previous_date_billing"] = DateTime.Now;
                }

                RecordBySerial.Rows[i]["previous_date_billingTemp"] = RecordBySerial.Rows[i]["previous_date_billing"];

                RecordBySerial.Rows[i]["present_energy_valueTemp"] = RecordBySerial.Rows[i]["present_energy_value"];
                if (RecordBySerial.Rows[i]["present_date_update"].ToString() == "")
                {
                    RecordBySerial.Rows[i]["present_date_updateTemp"] = DateTime.Now;
                }
                else
                {
                    RecordBySerial.Rows[i]["present_date_updateTemp"] = RecordBySerial.Rows[i]["present_date_update"];
                }

                if (RecordBySerial.Rows[i]["previous_date_billing"].ToString() == "")
                {
                    //check_in_electricit_date 	check_in_electricitymeter 	check_in_watermeter 	check_in_water_date 

                    CheckinInfo = BusinessLogicBridge.DataStore.ReadStartMeterByRoomIDFromCheckIn(RecordBySerial.Rows[i]["room_id"].ToString());

                    if (CheckinInfo.Rows.Count > 0)
                    {
                        RecordBySerial.Rows[i]["flag_type_previous"] = "fromcheckin";
                        RecordBySerial.Rows[i]["previous_date_billing"] = CheckinInfo.Rows[0]["check_in_electricit_date"];
                        RecordBySerial.Rows[i]["previous_energy_billing"] = CheckinInfo.Rows[0]["check_in_electricitymeter"];

                        // Clone to Temp
                        RecordBySerial.Rows[i]["previous_energy_billingTemp"] = RecordBySerial.Rows[i]["previous_energy_billing"];
                        RecordBySerial.Rows[i]["previous_date_billingTemp"] = RecordBySerial.Rows[i]["previous_date_billing"];

                    }

                }
                else
                {
                    RecordBySerial.Rows[i]["flag_type_previous"] = "frombilling";
                }

                if (RecordBySerial.Rows[i]["meter_status"].To<bool>()==false)
                {
                    RecordBySerial.Rows[i]["E_CommStatus"] = "FAIL";
                }
                else
                {
                    RecordBySerial.Rows[i]["E_CommStatus"] = "PASS";
                }

                if (RecordBySerial.Rows[i]["meter_cut"].ToString() == "False")
                {
                    RecordBySerial.Rows[i]["meter_cut_text"] = "Open";
                }
                else
                {
                    RecordBySerial.Rows[i]["meter_cut_text"] = "Closed";
                }
            }

            gridControlMeterInRoom.DataSource = RecordBySerial;
            #endregion

            #region Meter Utility
            DataTable RecordBySerialUtility = BusinessLogicBridge.DataStore.ReadRecordingUtilityByDate(datetime);

            DataTable CheckinInfoUtility = new DataTable("CheckinInfoUtility");

            RecordBySerialUtility.Columns.Add("total_unit", typeof(string));
            RecordBySerialUtility.Columns.Add("flag_type_previous", typeof(string));
            RecordBySerialUtility.Columns.Add("previous_energy_billingTemp");
            RecordBySerialUtility.Columns.Add("previous_date_billingTemp");
            RecordBySerialUtility.Columns.Add("present_energy_valueTemp");
            RecordBySerialUtility.Columns.Add("present_date_updateTemp");
            RecordBySerialUtility.Columns.Add("E_CommStatus");
            RecordBySerialUtility.Columns.Add("meter_cut_text");

            for (int i = 0; i < RecordBySerialUtility.Rows.Count; i++)
            {

                RecordBySerialUtility.Rows[i]["previous_energy_billingTemp"] = RecordBySerialUtility.Rows[i]["previous_energy_billing"];
                RecordBySerialUtility.Rows[i]["previous_date_billingTemp"] = RecordBySerialUtility.Rows[i]["previous_date_billing"];

                RecordBySerialUtility.Rows[i]["present_energy_valueTemp"] = RecordBySerialUtility.Rows[i]["present_energy_value"];
                RecordBySerialUtility.Rows[i]["present_date_updateTemp"] = RecordBySerialUtility.Rows[i]["present_date_update"];

                //if (RecordBySerialUtility.Rows[i]["previous_date_billing"].ToString() == "")
                //{
                //    //check_in_electricit_date 	check_in_electricitymeter 	check_in_watermeter 	check_in_water_date 

                //    CheckinInfoUtility = BusinessLogicBridge.DataStore.ReadStartMeterByRoomIDFromCheckIn(RecordBySerialUtility.Rows[i]["room_id"].ToString());

                //    if (CheckinInfoUtility.Rows.Count > 0)
                //    {
                //        RecordBySerialUtility.Rows[i]["flag_type_previous"] = "fromcheckin";
                //        RecordBySerialUtility.Rows[i]["previous_date_billing"] = CheckinInfoUtility.Rows[0]["check_in_electricit_date"];
                //        RecordBySerialUtility.Rows[i]["previous_energy_billing"] = CheckinInfoUtility.Rows[0]["check_in_electricitymeter"];

                //        // Clone to Temp
                //        RecordBySerialUtility.Rows[i]["previous_energy_billingTemp"] = RecordBySerialUtility.Rows[i]["previous_energy_billing"];
                //        RecordBySerialUtility.Rows[i]["previous_date_billingTemp"] = RecordBySerialUtility.Rows[i]["previous_date_billing"];

                //    }

                //}
                //else
                //{
                //    RecordBySerialUtility.Rows[i]["flag_type_previous"] = "frombilling";
                //}

                if (RecordBySerialUtility.Rows[i]["e_connection"].ToString() == "0")
                {

                    RecordBySerialUtility.Rows[i]["E_CommStatus"] = "FAIL";

                }
                else
                {

                    RecordBySerialUtility.Rows[i]["E_CommStatus"] = "PASS";
                }

                if (RecordBySerialUtility.Rows[i]["meter_cut"].ToString() == "False")
                {
                    RecordBySerialUtility.Rows[i]["meter_cut_text"] = "Open";
                }
                else
                {
                    RecordBySerialUtility.Rows[i]["meter_cut_text"] = "Closed";
                }

            }



            gridControlMeterUtility.DataSource = RecordBySerialUtility;
            #endregion
        }

        private void setEnable()
        {
            gridViewMeterInRoom.Columns[3].OptionsColumn.AllowEdit = true;
            gridViewMeterInRoom.Columns[4].OptionsColumn.AllowEdit = true;

            gridViewMeterInRoom.Columns[5].OptionsColumn.AllowEdit = true;
            gridViewMeterInRoom.Columns[6].OptionsColumn.AllowEdit = true;

            bttSave.Enabled = true;
            bttCancel.Enabled = true;

            bttEdit.Enabled = false;

        }

        private void setDisable()
        {
            gridViewMeterInRoom.Columns[3].OptionsColumn.AllowEdit = false;
            gridViewMeterInRoom.Columns[4].OptionsColumn.AllowEdit = false;

            gridViewMeterInRoom.Columns[5].OptionsColumn.AllowEdit = false;
            gridViewMeterInRoom.Columns[6].OptionsColumn.AllowEdit = false;

            bttSave.Enabled = false;
            bttCancel.Enabled = false;

            bttEdit.Enabled = true;

        }

        private void bttEdit_Click(object sender, EventArgs e)
        {
            setEnable();
        }

        private void bttSave_Click(object sender, EventArgs e)
        {
            DataRow UpdateRow;

            for (int i = 0; i < rowUpdated.Count; i++) {
                
                UpdateRow = gridViewMeterInRoom.GetDataRow(rowUpdated[i]);
                // Insert Transaction Electric meter
                BusinessLogicBridge.DataStore.insertE_Record(UpdateRow);
            }            
            setDisable();
        }
    }
}
