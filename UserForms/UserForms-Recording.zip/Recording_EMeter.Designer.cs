﻿namespace DXWindowsApplication2.UserForms
{
    partial class Recording_EMeter
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            this.panelControl8 = new DevExpress.XtraEditors.PanelControl();
            this.bttEdit = new DevExpress.XtraEditors.SimpleButton();
            this.bttCancel = new DevExpress.XtraEditors.SimpleButton();
            this.bttSave = new DevExpress.XtraEditors.SimpleButton();
            this.bttReplace = new DevExpress.XtraEditors.SimpleButton();
            this.labelControlBuilding = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEditBuilding = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControlRecordDate = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEditRecordDate = new DevExpress.XtraEditors.LookUpEdit();
            this.groupControlEMeter = new DevExpress.XtraEditors.GroupControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.xtraScrollableControl1 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.groupBoxUtility = new System.Windows.Forms.GroupBox();
            this.gridControlMeterUtility = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupBoxMeterInRoom = new System.Windows.Forms.GroupBox();
            this.gridControlMeterInRoom = new DevExpress.XtraGrid.GridControl();
            this.gridViewMeterInRoom = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumnRoomName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnMeterName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnMeterModels = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPreviousDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPreviousEnergy = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPresentRecordDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPresentEnergy = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnTotalUnit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnReading = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditReading = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumnConnection = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnStatus = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridMeterCut = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPreviousEnergyTemp = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPreviousDateTemp = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnflag_type_previous = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnE_MeterID = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl8)).BeginInit();
            this.panelControl8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditBuilding.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditRecordDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlEMeter)).BeginInit();
            this.groupControlEMeter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            this.xtraScrollableControl1.SuspendLayout();
            this.groupBoxUtility.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlMeterUtility)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).BeginInit();
            this.groupBoxMeterInRoom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlMeterInRoom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMeterInRoom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditReading)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl8
            // 
            this.panelControl8.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
            this.panelControl8.Appearance.Options.UseBackColor = true;
            this.panelControl8.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.panelControl8.Controls.Add(this.bttEdit);
            this.panelControl8.Controls.Add(this.bttCancel);
            this.panelControl8.Controls.Add(this.bttSave);
            this.panelControl8.Controls.Add(this.bttReplace);
            this.panelControl8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelControl8.Location = new System.Drawing.Point(7, 557);
            this.panelControl8.Name = "panelControl8";
            this.panelControl8.Size = new System.Drawing.Size(1088, 83);
            this.panelControl8.TabIndex = 419;
            // 
            // bttEdit
            // 
            this.bttEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bttEdit.Image = global::DXWindowsApplication2.Properties.Resources.edit;
            this.bttEdit.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.bttEdit.Location = new System.Drawing.Point(863, 22);
            this.bttEdit.Name = "bttEdit";
            this.bttEdit.Size = new System.Drawing.Size(70, 55);
            this.bttEdit.TabIndex = 19;
            this.bttEdit.Text = "แก้ไขข้อมูล";
            this.bttEdit.Click += new System.EventHandler(this.bttEdit_Click);
            // 
            // bttCancel
            // 
            this.bttCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bttCancel.Enabled = false;
            this.bttCancel.Image = global::DXWindowsApplication2.Properties.Resources.Close;
            this.bttCancel.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.bttCancel.Location = new System.Drawing.Point(1015, 22);
            this.bttCancel.Name = "bttCancel";
            this.bttCancel.Size = new System.Drawing.Size(70, 55);
            this.bttCancel.TabIndex = 22;
            this.bttCancel.Text = "ยกเลิก";
            // 
            // bttSave
            // 
            this.bttSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bttSave.Enabled = false;
            this.bttSave.Image = global::DXWindowsApplication2.Properties.Resources.savedisk;
            this.bttSave.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.bttSave.Location = new System.Drawing.Point(939, 22);
            this.bttSave.Name = "bttSave";
            this.bttSave.Size = new System.Drawing.Size(70, 55);
            this.bttSave.TabIndex = 21;
            this.bttSave.Text = "บันทึก";
            this.bttSave.Click += new System.EventHandler(this.bttSave_Click);
            // 
            // bttReplace
            // 
            this.bttReplace.Image = global::DXWindowsApplication2.Properties.Resources.refresh;
            this.bttReplace.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleLeft;
            this.bttReplace.Location = new System.Drawing.Point(7, 22);
            this.bttReplace.Name = "bttReplace";
            this.bttReplace.Size = new System.Drawing.Size(94, 55);
            this.bttReplace.TabIndex = 431;
            this.bttReplace.Text = "Read All";
            // 
            // labelControlBuilding
            // 
            this.labelControlBuilding.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControlBuilding.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControlBuilding.Location = new System.Drawing.Point(7, 37);
            this.labelControlBuilding.Name = "labelControlBuilding";
            this.labelControlBuilding.Size = new System.Drawing.Size(72, 17);
            this.labelControlBuilding.TabIndex = 22;
            this.labelControlBuilding.Text = "อาคาร :";
            // 
            // lookUpEditBuilding
            // 
            this.lookUpEditBuilding.Location = new System.Drawing.Point(85, 36);
            this.lookUpEditBuilding.Name = "lookUpEditBuilding";
            this.lookUpEditBuilding.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditBuilding.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("building_id", "", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("building_code", " ")});
            this.lookUpEditBuilding.Size = new System.Drawing.Size(139, 20);
            this.lookUpEditBuilding.TabIndex = 21;
            // 
            // labelControlRecordDate
            // 
            this.labelControlRecordDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControlRecordDate.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControlRecordDate.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControlRecordDate.Location = new System.Drawing.Point(839, 37);
            this.labelControlRecordDate.Name = "labelControlRecordDate";
            this.labelControlRecordDate.Size = new System.Drawing.Size(84, 17);
            this.labelControlRecordDate.TabIndex = 24;
            this.labelControlRecordDate.Text = "Record Date :";
            // 
            // lookUpEditRecordDate
            // 
            this.lookUpEditRecordDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lookUpEditRecordDate.Location = new System.Drawing.Point(929, 36);
            this.lookUpEditRecordDate.Name = "lookUpEditRecordDate";
            this.lookUpEditRecordDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditRecordDate.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("groupdate", "", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("groupdate", " ", 20, DevExpress.Utils.FormatType.DateTime, "d", true, DevExpress.Utils.HorzAlignment.Default)});
            this.lookUpEditRecordDate.Properties.DisplayFormat.FormatString = "d";
            this.lookUpEditRecordDate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.lookUpEditRecordDate.Properties.EditFormat.FormatString = "d";
            this.lookUpEditRecordDate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.lookUpEditRecordDate.Size = new System.Drawing.Size(139, 20);
            this.lookUpEditRecordDate.TabIndex = 23;
            // 
            // groupControlEMeter
            // 
            this.groupControlEMeter.Controls.Add(this.lookUpEditRecordDate);
            this.groupControlEMeter.Controls.Add(this.labelControlRecordDate);
            this.groupControlEMeter.Controls.Add(this.lookUpEditBuilding);
            this.groupControlEMeter.Controls.Add(this.labelControlBuilding);
            this.groupControlEMeter.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupControlEMeter.Location = new System.Drawing.Point(7, 7);
            this.groupControlEMeter.Name = "groupControlEMeter";
            this.groupControlEMeter.Size = new System.Drawing.Size(1088, 67);
            this.groupControlEMeter.TabIndex = 0;
            this.groupControlEMeter.Text = "E-Meter";
            // 
            // gridView2
            // 
            this.gridView2.Name = "gridView2";
            // 
            // xtraScrollableControl1
            // 
            this.xtraScrollableControl1.Controls.Add(this.groupBoxUtility);
            this.xtraScrollableControl1.Controls.Add(this.groupBoxMeterInRoom);
            this.xtraScrollableControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.xtraScrollableControl1.Location = new System.Drawing.Point(7, 74);
            this.xtraScrollableControl1.Name = "xtraScrollableControl1";
            this.xtraScrollableControl1.Size = new System.Drawing.Size(1088, 385);
            this.xtraScrollableControl1.TabIndex = 420;
            // 
            // groupBoxUtility
            // 
            this.groupBoxUtility.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
            this.groupBoxUtility.Controls.Add(this.gridControlMeterUtility);
            this.groupBoxUtility.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxUtility.Location = new System.Drawing.Point(0, 180);
            this.groupBoxUtility.Name = "groupBoxUtility";
            this.groupBoxUtility.Size = new System.Drawing.Size(1088, 203);
            this.groupBoxUtility.TabIndex = 4;
            this.groupBoxUtility.TabStop = false;
            this.groupBoxUtility.Text = "Utility Meter";
            // 
            // gridControlMeterUtility
            // 
            this.gridControlMeterUtility.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlMeterUtility.Location = new System.Drawing.Point(3, 17);
            this.gridControlMeterUtility.MainView = this.gridView1;
            this.gridControlMeterUtility.Name = "gridControlMeterUtility";
            this.gridControlMeterUtility.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEdit1});
            this.gridControlMeterUtility.Size = new System.Drawing.Size(1082, 183);
            this.gridControlMeterUtility.TabIndex = 1;
            this.gridControlMeterUtility.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn12,
            this.gridColumn13,
            this.gridColumn14,
            this.gridColumn15,
            this.gridColumn16,
            this.gridColumn17,
            this.gridColumn18,
            this.gridColumn19,
            this.gridColumn20});
            this.gridView1.GridControl = this.gridControlMeterUtility;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn1.AppearanceHeader.Options.UseFont = true;
            this.gridColumn1.Caption = "Room Name";
            this.gridColumn1.FieldName = "room_label";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.OptionsColumn.AllowFocus = false;
            this.gridColumn1.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumn1.OptionsColumn.AllowMove = false;
            this.gridColumn1.OptionsColumn.ReadOnly = true;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 56;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn2.AppearanceHeader.Options.UseFont = true;
            this.gridColumn2.Caption = "Meter Name";
            this.gridColumn2.FieldName = "meter_label";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.OptionsColumn.AllowFocus = false;
            this.gridColumn2.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumn2.OptionsColumn.AllowMove = false;
            this.gridColumn2.OptionsColumn.ReadOnly = true;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 53;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn3.AppearanceHeader.Options.UseFont = true;
            this.gridColumn3.Caption = "Model";
            this.gridColumn3.FieldName = "meter_models";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.OptionsColumn.AllowFocus = false;
            this.gridColumn3.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumn3.OptionsColumn.AllowMove = false;
            this.gridColumn3.OptionsColumn.ReadOnly = true;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            this.gridColumn3.Width = 55;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn4.AppearanceHeader.Options.UseFont = true;
            this.gridColumn4.Caption = "Previous Date (Billing)";
            this.gridColumn4.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumn4.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn4.FieldName = "previous_date_billing";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            this.gridColumn4.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumn4.OptionsColumn.AllowMove = false;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 3;
            this.gridColumn4.Width = 97;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn5.AppearanceHeader.Options.UseFont = true;
            this.gridColumn5.Caption = "Previous Energy (Billing)";
            this.gridColumn5.DisplayFormat.FormatString = "n1";
            this.gridColumn5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn5.FieldName = "previous_energy_billing";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumn5.OptionsColumn.AllowMove = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 4;
            this.gridColumn5.Width = 107;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn6.AppearanceHeader.Options.UseFont = true;
            this.gridColumn6.Caption = "Present Record Date";
            this.gridColumn6.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumn6.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn6.FieldName = "present_date_update";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumn6.OptionsColumn.AllowMove = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 5;
            this.gridColumn6.Width = 91;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn7.AppearanceHeader.Options.UseFont = true;
            this.gridColumn7.Caption = "Present Energy";
            this.gridColumn7.DisplayFormat.FormatString = "n1";
            this.gridColumn7.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn7.FieldName = "present_energy_value";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumn7.OptionsColumn.AllowMove = false;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 6;
            this.gridColumn7.Width = 68;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn10.AppearanceHeader.Options.UseFont = true;
            this.gridColumn10.Caption = "Total Unit";
            this.gridColumn10.DisplayFormat.FormatString = "n1";
            this.gridColumn10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn10.FieldName = "total_unit";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.AllowEdit = false;
            this.gridColumn10.OptionsColumn.AllowFocus = false;
            this.gridColumn10.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumn10.OptionsColumn.AllowMove = false;
            this.gridColumn10.OptionsColumn.ReadOnly = true;
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 7;
            this.gridColumn10.Width = 55;
            // 
            // gridColumn11
            // 
            this.gridColumn11.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn11.AppearanceHeader.Options.UseFont = true;
            this.gridColumn11.Caption = "Read";
            this.gridColumn11.ColumnEdit = this.repositoryItemButtonEdit1;
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumn11.OptionsColumn.AllowMove = false;
            this.gridColumn11.OptionsColumn.ReadOnly = true;
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 8;
            this.gridColumn11.Width = 55;
            // 
            // repositoryItemButtonEdit1
            // 
            this.repositoryItemButtonEdit1.AccessibleDescription = "Read";
            this.repositoryItemButtonEdit1.AccessibleName = "Read";
            this.repositoryItemButtonEdit1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.repositoryItemButtonEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Ellipsis, "Read", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, true)});
            this.repositoryItemButtonEdit1.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.repositoryItemButtonEdit1.Name = "repositoryItemButtonEdit1";
            this.repositoryItemButtonEdit1.NullText = "Read";
            this.repositoryItemButtonEdit1.NullValuePrompt = "Read";
            this.repositoryItemButtonEdit1.NullValuePromptShowForEmptyValue = true;
            this.repositoryItemButtonEdit1.ReadOnly = true;
            this.repositoryItemButtonEdit1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEdit1.UseParentBackground = true;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn12.AppearanceHeader.Options.UseFont = true;
            this.gridColumn12.Caption = "Meter Connection";
            this.gridColumn12.FieldName = "E_CommStatus";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsColumn.AllowEdit = false;
            this.gridColumn12.OptionsColumn.AllowFocus = false;
            this.gridColumn12.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumn12.OptionsColumn.AllowMove = false;
            this.gridColumn12.OptionsColumn.ReadOnly = true;
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 9;
            this.gridColumn12.Width = 79;
            // 
            // gridColumn13
            // 
            this.gridColumn13.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumn13.AppearanceHeader.Options.UseFont = true;
            this.gridColumn13.Caption = "Meter Status";
            this.gridColumn13.FieldName = "meter_cut_text";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.OptionsColumn.AllowEdit = false;
            this.gridColumn13.OptionsColumn.AllowFocus = false;
            this.gridColumn13.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumn13.OptionsColumn.AllowMove = false;
            this.gridColumn13.OptionsColumn.ReadOnly = true;
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 10;
            this.gridColumn13.Width = 60;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = "Meter Cut";
            this.gridColumn14.FieldName = "meter_cut";
            this.gridColumn14.Name = "gridColumn14";
            // 
            // gridColumn15
            // 
            this.gridColumn15.Caption = "previous_energy_billing ( Temp )";
            this.gridColumn15.DisplayFormat.FormatString = "n1";
            this.gridColumn15.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn15.FieldName = "previous_energy_billingTemp";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 11;
            this.gridColumn15.Width = 55;
            // 
            // gridColumn16
            // 
            this.gridColumn16.Caption = "previous_date_billingTemp";
            this.gridColumn16.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumn16.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn16.FieldName = "previous_date_billingTemp";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 12;
            this.gridColumn16.Width = 55;
            // 
            // gridColumn17
            // 
            this.gridColumn17.Caption = "Flag";
            this.gridColumn17.FieldName = "flag_type_previous";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 13;
            this.gridColumn17.Width = 55;
            // 
            // gridColumn18
            // 
            this.gridColumn18.Caption = "present_energy_valueTemp( Temp )";
            this.gridColumn18.DisplayFormat.FormatString = "n1";
            this.gridColumn18.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn18.FieldName = "present_energy_valueTemp";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 14;
            this.gridColumn18.Width = 55;
            // 
            // gridColumn19
            // 
            this.gridColumn19.Caption = "present_date_updateTemp";
            this.gridColumn19.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumn19.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn19.FieldName = "present_date_updateTemp";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 15;
            this.gridColumn19.Width = 68;
            // 
            // gridColumn20
            // 
            this.gridColumn20.Caption = "gridColumnE_MeterID";
            this.gridColumn20.FieldName = "meter_id";
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 16;
            // 
            // groupBoxMeterInRoom
            // 
            this.groupBoxMeterInRoom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
            this.groupBoxMeterInRoom.Controls.Add(this.gridControlMeterInRoom);
            this.groupBoxMeterInRoom.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxMeterInRoom.Location = new System.Drawing.Point(0, 0);
            this.groupBoxMeterInRoom.Name = "groupBoxMeterInRoom";
            this.groupBoxMeterInRoom.Size = new System.Drawing.Size(1088, 180);
            this.groupBoxMeterInRoom.TabIndex = 3;
            this.groupBoxMeterInRoom.TabStop = false;
            this.groupBoxMeterInRoom.Text = "Meter In Room";
            // 
            // gridControlMeterInRoom
            // 
            this.gridControlMeterInRoom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlMeterInRoom.Location = new System.Drawing.Point(3, 17);
            this.gridControlMeterInRoom.MainView = this.gridViewMeterInRoom;
            this.gridControlMeterInRoom.Name = "gridControlMeterInRoom";
            this.gridControlMeterInRoom.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEditReading});
            this.gridControlMeterInRoom.Size = new System.Drawing.Size(1082, 160);
            this.gridControlMeterInRoom.TabIndex = 0;
            this.gridControlMeterInRoom.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewMeterInRoom});
            // 
            // gridViewMeterInRoom
            // 
            this.gridViewMeterInRoom.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumnRoomName,
            this.gridColumnMeterName,
            this.gridColumnMeterModels,
            this.gridColumnPreviousDate,
            this.gridColumnPreviousEnergy,
            this.gridColumnPresentRecordDate,
            this.gridColumnPresentEnergy,
            this.gridColumnTotalUnit,
            this.gridColumnReading,
            this.gridColumnConnection,
            this.gridColumnStatus,
            this.gridMeterCut,
            this.gridColumnPreviousEnergyTemp,
            this.gridColumnPreviousDateTemp,
            this.gridColumnflag_type_previous,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumnE_MeterID});
            this.gridViewMeterInRoom.GridControl = this.gridControlMeterInRoom;
            this.gridViewMeterInRoom.Name = "gridViewMeterInRoom";
            this.gridViewMeterInRoom.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumnRoomName
            // 
            this.gridColumnRoomName.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnRoomName.AppearanceHeader.Options.UseFont = true;
            this.gridColumnRoomName.Caption = "Room Name";
            this.gridColumnRoomName.FieldName = "room_label";
            this.gridColumnRoomName.Name = "gridColumnRoomName";
            this.gridColumnRoomName.OptionsColumn.AllowEdit = false;
            this.gridColumnRoomName.OptionsColumn.AllowFocus = false;
            this.gridColumnRoomName.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnRoomName.OptionsColumn.AllowMove = false;
            this.gridColumnRoomName.OptionsColumn.ReadOnly = true;
            this.gridColumnRoomName.Visible = true;
            this.gridColumnRoomName.VisibleIndex = 0;
            this.gridColumnRoomName.Width = 56;
            // 
            // gridColumnMeterName
            // 
            this.gridColumnMeterName.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnMeterName.AppearanceHeader.Options.UseFont = true;
            this.gridColumnMeterName.Caption = "Meter Name";
            this.gridColumnMeterName.FieldName = "meter_label";
            this.gridColumnMeterName.Name = "gridColumnMeterName";
            this.gridColumnMeterName.OptionsColumn.AllowEdit = false;
            this.gridColumnMeterName.OptionsColumn.AllowFocus = false;
            this.gridColumnMeterName.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnMeterName.OptionsColumn.AllowMove = false;
            this.gridColumnMeterName.OptionsColumn.ReadOnly = true;
            this.gridColumnMeterName.Visible = true;
            this.gridColumnMeterName.VisibleIndex = 1;
            this.gridColumnMeterName.Width = 53;
            // 
            // gridColumnMeterModels
            // 
            this.gridColumnMeterModels.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnMeterModels.AppearanceHeader.Options.UseFont = true;
            this.gridColumnMeterModels.Caption = "Model";
            this.gridColumnMeterModels.FieldName = "meter_models";
            this.gridColumnMeterModels.Name = "gridColumnMeterModels";
            this.gridColumnMeterModels.OptionsColumn.AllowEdit = false;
            this.gridColumnMeterModels.OptionsColumn.AllowFocus = false;
            this.gridColumnMeterModels.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnMeterModels.OptionsColumn.AllowMove = false;
            this.gridColumnMeterModels.OptionsColumn.ReadOnly = true;
            this.gridColumnMeterModels.Visible = true;
            this.gridColumnMeterModels.VisibleIndex = 2;
            this.gridColumnMeterModels.Width = 55;
            // 
            // gridColumnPreviousDate
            // 
            this.gridColumnPreviousDate.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnPreviousDate.AppearanceHeader.Options.UseFont = true;
            this.gridColumnPreviousDate.Caption = "Previous Date (Billing)";
            this.gridColumnPreviousDate.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumnPreviousDate.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumnPreviousDate.FieldName = "previous_date_billing";
            this.gridColumnPreviousDate.Name = "gridColumnPreviousDate";
            this.gridColumnPreviousDate.OptionsColumn.AllowEdit = false;
            this.gridColumnPreviousDate.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPreviousDate.OptionsColumn.AllowMove = false;
            this.gridColumnPreviousDate.Visible = true;
            this.gridColumnPreviousDate.VisibleIndex = 3;
            this.gridColumnPreviousDate.Width = 97;
            // 
            // gridColumnPreviousEnergy
            // 
            this.gridColumnPreviousEnergy.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnPreviousEnergy.AppearanceHeader.Options.UseFont = true;
            this.gridColumnPreviousEnergy.Caption = "Previous Energy (Billing)";
            this.gridColumnPreviousEnergy.DisplayFormat.FormatString = "n1";
            this.gridColumnPreviousEnergy.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnPreviousEnergy.FieldName = "previous_energy_billing";
            this.gridColumnPreviousEnergy.Name = "gridColumnPreviousEnergy";
            this.gridColumnPreviousEnergy.OptionsColumn.AllowEdit = false;
            this.gridColumnPreviousEnergy.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPreviousEnergy.OptionsColumn.AllowMove = false;
            this.gridColumnPreviousEnergy.Visible = true;
            this.gridColumnPreviousEnergy.VisibleIndex = 4;
            this.gridColumnPreviousEnergy.Width = 107;
            // 
            // gridColumnPresentRecordDate
            // 
            this.gridColumnPresentRecordDate.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnPresentRecordDate.AppearanceHeader.Options.UseFont = true;
            this.gridColumnPresentRecordDate.Caption = "Present Record Date";
            this.gridColumnPresentRecordDate.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumnPresentRecordDate.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumnPresentRecordDate.FieldName = "present_date_update";
            this.gridColumnPresentRecordDate.Name = "gridColumnPresentRecordDate";
            this.gridColumnPresentRecordDate.OptionsColumn.AllowEdit = false;
            this.gridColumnPresentRecordDate.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPresentRecordDate.OptionsColumn.AllowMove = false;
            this.gridColumnPresentRecordDate.Visible = true;
            this.gridColumnPresentRecordDate.VisibleIndex = 5;
            this.gridColumnPresentRecordDate.Width = 91;
            // 
            // gridColumnPresentEnergy
            // 
            this.gridColumnPresentEnergy.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnPresentEnergy.AppearanceHeader.Options.UseFont = true;
            this.gridColumnPresentEnergy.Caption = "Present Energy";
            this.gridColumnPresentEnergy.DisplayFormat.FormatString = "n1";
            this.gridColumnPresentEnergy.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnPresentEnergy.FieldName = "present_energy_value";
            this.gridColumnPresentEnergy.Name = "gridColumnPresentEnergy";
            this.gridColumnPresentEnergy.OptionsColumn.AllowEdit = false;
            this.gridColumnPresentEnergy.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPresentEnergy.OptionsColumn.AllowMove = false;
            this.gridColumnPresentEnergy.Visible = true;
            this.gridColumnPresentEnergy.VisibleIndex = 6;
            this.gridColumnPresentEnergy.Width = 68;
            // 
            // gridColumnTotalUnit
            // 
            this.gridColumnTotalUnit.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnTotalUnit.AppearanceHeader.Options.UseFont = true;
            this.gridColumnTotalUnit.Caption = "Total Unit";
            this.gridColumnTotalUnit.DisplayFormat.FormatString = "n1";
            this.gridColumnTotalUnit.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnTotalUnit.FieldName = "total_unit";
            this.gridColumnTotalUnit.Name = "gridColumnTotalUnit";
            this.gridColumnTotalUnit.OptionsColumn.AllowEdit = false;
            this.gridColumnTotalUnit.OptionsColumn.AllowFocus = false;
            this.gridColumnTotalUnit.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnTotalUnit.OptionsColumn.AllowMove = false;
            this.gridColumnTotalUnit.OptionsColumn.ReadOnly = true;
            this.gridColumnTotalUnit.Visible = true;
            this.gridColumnTotalUnit.VisibleIndex = 7;
            this.gridColumnTotalUnit.Width = 55;
            // 
            // gridColumnReading
            // 
            this.gridColumnReading.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnReading.AppearanceHeader.Options.UseFont = true;
            this.gridColumnReading.Caption = "Read";
            this.gridColumnReading.ColumnEdit = this.repositoryItemButtonEditReading;
            this.gridColumnReading.Name = "gridColumnReading";
            this.gridColumnReading.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnReading.OptionsColumn.AllowMove = false;
            this.gridColumnReading.OptionsColumn.ReadOnly = true;
            this.gridColumnReading.Visible = true;
            this.gridColumnReading.VisibleIndex = 8;
            this.gridColumnReading.Width = 55;
            // 
            // repositoryItemButtonEditReading
            // 
            this.repositoryItemButtonEditReading.AccessibleDescription = "Read";
            this.repositoryItemButtonEditReading.AccessibleName = "Read";
            this.repositoryItemButtonEditReading.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.repositoryItemButtonEditReading.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Ellipsis, "Read", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject2, "", null, null, true)});
            this.repositoryItemButtonEditReading.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.repositoryItemButtonEditReading.Name = "repositoryItemButtonEditReading";
            this.repositoryItemButtonEditReading.NullText = "Read";
            this.repositoryItemButtonEditReading.NullValuePrompt = "Read";
            this.repositoryItemButtonEditReading.NullValuePromptShowForEmptyValue = true;
            this.repositoryItemButtonEditReading.ReadOnly = true;
            this.repositoryItemButtonEditReading.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditReading.UseParentBackground = true;
            // 
            // gridColumnConnection
            // 
            this.gridColumnConnection.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnConnection.AppearanceHeader.Options.UseFont = true;
            this.gridColumnConnection.Caption = "Meter Connection";
            this.gridColumnConnection.FieldName = "E_CommStatus";
            this.gridColumnConnection.Name = "gridColumnConnection";
            this.gridColumnConnection.OptionsColumn.AllowEdit = false;
            this.gridColumnConnection.OptionsColumn.AllowFocus = false;
            this.gridColumnConnection.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnConnection.OptionsColumn.AllowMove = false;
            this.gridColumnConnection.OptionsColumn.ReadOnly = true;
            this.gridColumnConnection.Visible = true;
            this.gridColumnConnection.VisibleIndex = 9;
            this.gridColumnConnection.Width = 79;
            // 
            // gridColumnStatus
            // 
            this.gridColumnStatus.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnStatus.AppearanceHeader.Options.UseFont = true;
            this.gridColumnStatus.Caption = "Meter Status";
            this.gridColumnStatus.FieldName = "meter_cut_text";
            this.gridColumnStatus.Name = "gridColumnStatus";
            this.gridColumnStatus.OptionsColumn.AllowEdit = false;
            this.gridColumnStatus.OptionsColumn.AllowFocus = false;
            this.gridColumnStatus.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnStatus.OptionsColumn.AllowMove = false;
            this.gridColumnStatus.OptionsColumn.ReadOnly = true;
            this.gridColumnStatus.Visible = true;
            this.gridColumnStatus.VisibleIndex = 10;
            this.gridColumnStatus.Width = 60;
            // 
            // gridMeterCut
            // 
            this.gridMeterCut.Caption = "Meter Cut";
            this.gridMeterCut.FieldName = "meter_cut";
            this.gridMeterCut.Name = "gridMeterCut";
            // 
            // gridColumnPreviousEnergyTemp
            // 
            this.gridColumnPreviousEnergyTemp.Caption = "previous_energy_billing ( Temp )";
            this.gridColumnPreviousEnergyTemp.DisplayFormat.FormatString = "n1";
            this.gridColumnPreviousEnergyTemp.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnPreviousEnergyTemp.FieldName = "previous_energy_billingTemp";
            this.gridColumnPreviousEnergyTemp.Name = "gridColumnPreviousEnergyTemp";
            this.gridColumnPreviousEnergyTemp.Width = 55;
            // 
            // gridColumnPreviousDateTemp
            // 
            this.gridColumnPreviousDateTemp.Caption = "previous_date_billingTemp";
            this.gridColumnPreviousDateTemp.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumnPreviousDateTemp.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumnPreviousDateTemp.FieldName = "previous_date_billingTemp";
            this.gridColumnPreviousDateTemp.Name = "gridColumnPreviousDateTemp";
            this.gridColumnPreviousDateTemp.Visible = true;
            this.gridColumnPreviousDateTemp.VisibleIndex = 11;
            this.gridColumnPreviousDateTemp.Width = 55;
            // 
            // gridColumnflag_type_previous
            // 
            this.gridColumnflag_type_previous.Caption = "Flag";
            this.gridColumnflag_type_previous.FieldName = "flag_type_previous";
            this.gridColumnflag_type_previous.Name = "gridColumnflag_type_previous";
            this.gridColumnflag_type_previous.Width = 55;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "present_energy_valueTemp( Temp )";
            this.gridColumn8.DisplayFormat.FormatString = "n1";
            this.gridColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn8.FieldName = "present_energy_valueTemp";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Width = 55;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "present_date_updateTemp";
            this.gridColumn9.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn9.FieldName = "present_date_updateTemp";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 12;
            this.gridColumn9.Width = 68;
            // 
            // gridColumnE_MeterID
            // 
            this.gridColumnE_MeterID.Caption = "gridColumnE_MeterID";
            this.gridColumnE_MeterID.FieldName = "meter_id";
            this.gridColumnE_MeterID.Name = "gridColumnE_MeterID";
            // 
            // Recording_EMeter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraScrollableControl1);
            this.Controls.Add(this.panelControl8);
            this.Controls.Add(this.groupControlEMeter);
            this.Name = "Recording_EMeter";
            this.Padding = new System.Windows.Forms.Padding(7);
            this.Size = new System.Drawing.Size(1102, 647);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl8)).EndInit();
            this.panelControl8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditBuilding.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditRecordDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlEMeter)).EndInit();
            this.groupControlEMeter.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            this.xtraScrollableControl1.ResumeLayout(false);
            this.groupBoxUtility.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlMeterUtility)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).EndInit();
            this.groupBoxMeterInRoom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlMeterInRoom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMeterInRoom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditReading)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl8;
        private DevExpress.XtraEditors.SimpleButton bttEdit;
        private DevExpress.XtraEditors.SimpleButton bttCancel;
        private DevExpress.XtraEditors.SimpleButton bttSave;
        private DevExpress.XtraEditors.SimpleButton bttReplace;
        private DevExpress.XtraEditors.LabelControl labelControlBuilding;
        private DevExpress.XtraEditors.LookUpEdit lookUpEditBuilding;
        private DevExpress.XtraEditors.LabelControl labelControlRecordDate;
        private DevExpress.XtraEditors.LookUpEdit lookUpEditRecordDate;
        private DevExpress.XtraEditors.GroupControl groupControlEMeter;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl1;
        private System.Windows.Forms.GroupBox groupBoxUtility;
        private System.Windows.Forms.GroupBox groupBoxMeterInRoom;
        private DevExpress.XtraGrid.GridControl gridControlMeterInRoom;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewMeterInRoom;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnRoomName;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnMeterName;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnMeterModels;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPreviousDate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPreviousEnergy;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPresentRecordDate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPresentEnergy;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnTotalUnit;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnReading;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnConnection;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnStatus;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditReading;
        private DevExpress.XtraGrid.Columns.GridColumn gridMeterCut;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPreviousEnergyTemp;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPreviousDateTemp;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnflag_type_previous;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnE_MeterID;
        private DevExpress.XtraGrid.GridControl gridControlMeterUtility;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
    }
}
