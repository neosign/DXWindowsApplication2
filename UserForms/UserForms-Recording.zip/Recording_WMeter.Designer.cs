﻿namespace DXWindowsApplication2.UserForms
{
    partial class Recording_WMeter
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            this.panelControl8 = new DevExpress.XtraEditors.PanelControl();
            this.bttEdit = new DevExpress.XtraEditors.SimpleButton();
            this.bttCancel = new DevExpress.XtraEditors.SimpleButton();
            this.bttSave = new DevExpress.XtraEditors.SimpleButton();
            this.bttReplace = new DevExpress.XtraEditors.SimpleButton();
            this.labelControlBuilding = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEditBuilding = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControlRecordDate = new DevExpress.XtraEditors.LabelControl();
            this.lookUpEditRecordDate = new DevExpress.XtraEditors.LookUpEdit();
            this.groupControlEMeter = new DevExpress.XtraEditors.GroupControl();
            this.lookUpEdit1 = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.xtraScrollableControl1 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.groupBoxMeterInRoom = new System.Windows.Forms.GroupBox();
            this.gridControlMeterInRoom = new DevExpress.XtraGrid.GridControl();
            this.gridViewMeterInRoom = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumnRoomName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnMeterName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPreviousDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPreviousEnergy = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPresentRecordDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPresentEnergy = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnTotalUnit = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnReading = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditReading = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumnConnection = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridMeterCut = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPreviousEnergyTemp = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnPreviousDateTemp = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnflag_type_previous = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumnE_MeterID = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl8)).BeginInit();
            this.panelControl8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditBuilding.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditRecordDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlEMeter)).BeginInit();
            this.groupControlEMeter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            this.xtraScrollableControl1.SuspendLayout();
            this.groupBoxMeterInRoom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlMeterInRoom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMeterInRoom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditReading)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl8
            // 
            this.panelControl8.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
            this.panelControl8.Appearance.Options.UseBackColor = true;
            this.panelControl8.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.panelControl8.Controls.Add(this.bttEdit);
            this.panelControl8.Controls.Add(this.bttCancel);
            this.panelControl8.Controls.Add(this.bttSave);
            this.panelControl8.Controls.Add(this.bttReplace);
            this.panelControl8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelControl8.Location = new System.Drawing.Point(7, 557);
            this.panelControl8.Name = "panelControl8";
            this.panelControl8.Size = new System.Drawing.Size(1088, 83);
            this.panelControl8.TabIndex = 419;
            // 
            // bttEdit
            // 
            this.bttEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bttEdit.Image = global::DXWindowsApplication2.Properties.Resources.edit;
            this.bttEdit.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.bttEdit.Location = new System.Drawing.Point(863, 22);
            this.bttEdit.Name = "bttEdit";
            this.bttEdit.Size = new System.Drawing.Size(70, 55);
            this.bttEdit.TabIndex = 19;
            this.bttEdit.Text = "แก้ไขข้อมูล";
            this.bttEdit.Click += new System.EventHandler(this.bttEdit_Click);
            // 
            // bttCancel
            // 
            this.bttCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bttCancel.Enabled = false;
            this.bttCancel.Image = global::DXWindowsApplication2.Properties.Resources.Close;
            this.bttCancel.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.bttCancel.Location = new System.Drawing.Point(1015, 22);
            this.bttCancel.Name = "bttCancel";
            this.bttCancel.Size = new System.Drawing.Size(70, 55);
            this.bttCancel.TabIndex = 22;
            this.bttCancel.Text = "ยกเลิก";
            // 
            // bttSave
            // 
            this.bttSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bttSave.Enabled = false;
            this.bttSave.Image = global::DXWindowsApplication2.Properties.Resources.savedisk;
            this.bttSave.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.bttSave.Location = new System.Drawing.Point(939, 22);
            this.bttSave.Name = "bttSave";
            this.bttSave.Size = new System.Drawing.Size(70, 55);
            this.bttSave.TabIndex = 21;
            this.bttSave.Text = "บันทึก";
            this.bttSave.Click += new System.EventHandler(this.bttSave_Click);
            // 
            // bttReplace
            // 
            this.bttReplace.Image = global::DXWindowsApplication2.Properties.Resources.refresh;
            this.bttReplace.ImageLocation = DevExpress.XtraEditors.ImageLocation.MiddleLeft;
            this.bttReplace.Location = new System.Drawing.Point(7, 22);
            this.bttReplace.Name = "bttReplace";
            this.bttReplace.Size = new System.Drawing.Size(94, 55);
            this.bttReplace.TabIndex = 431;
            this.bttReplace.Text = "Read All";
            // 
            // labelControlBuilding
            // 
            this.labelControlBuilding.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControlBuilding.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControlBuilding.Location = new System.Drawing.Point(7, 37);
            this.labelControlBuilding.Name = "labelControlBuilding";
            this.labelControlBuilding.Size = new System.Drawing.Size(72, 17);
            this.labelControlBuilding.TabIndex = 22;
            this.labelControlBuilding.Text = "อาคาร :";
            // 
            // lookUpEditBuilding
            // 
            this.lookUpEditBuilding.Location = new System.Drawing.Point(85, 36);
            this.lookUpEditBuilding.Name = "lookUpEditBuilding";
            this.lookUpEditBuilding.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditBuilding.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("building_id", "", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("building_code", " ")});
            this.lookUpEditBuilding.Size = new System.Drawing.Size(139, 20);
            this.lookUpEditBuilding.TabIndex = 21;
            // 
            // labelControlRecordDate
            // 
            this.labelControlRecordDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControlRecordDate.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControlRecordDate.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControlRecordDate.Location = new System.Drawing.Point(839, 37);
            this.labelControlRecordDate.Name = "labelControlRecordDate";
            this.labelControlRecordDate.Size = new System.Drawing.Size(84, 17);
            this.labelControlRecordDate.TabIndex = 24;
            this.labelControlRecordDate.Text = "Record Date :";
            // 
            // lookUpEditRecordDate
            // 
            this.lookUpEditRecordDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lookUpEditRecordDate.Location = new System.Drawing.Point(929, 36);
            this.lookUpEditRecordDate.Name = "lookUpEditRecordDate";
            this.lookUpEditRecordDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEditRecordDate.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("groupdate", "", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("groupdate", " ", 20, DevExpress.Utils.FormatType.DateTime, "d", true, DevExpress.Utils.HorzAlignment.Default)});
            this.lookUpEditRecordDate.Properties.DisplayFormat.FormatString = "d";
            this.lookUpEditRecordDate.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.lookUpEditRecordDate.Properties.EditFormat.FormatString = "d";
            this.lookUpEditRecordDate.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.lookUpEditRecordDate.Size = new System.Drawing.Size(139, 20);
            this.lookUpEditRecordDate.TabIndex = 23;
            // 
            // groupControlEMeter
            // 
            this.groupControlEMeter.Controls.Add(this.lookUpEdit1);
            this.groupControlEMeter.Controls.Add(this.labelControl1);
            this.groupControlEMeter.Controls.Add(this.lookUpEditRecordDate);
            this.groupControlEMeter.Controls.Add(this.labelControlRecordDate);
            this.groupControlEMeter.Controls.Add(this.lookUpEditBuilding);
            this.groupControlEMeter.Controls.Add(this.labelControlBuilding);
            this.groupControlEMeter.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupControlEMeter.Location = new System.Drawing.Point(7, 7);
            this.groupControlEMeter.Name = "groupControlEMeter";
            this.groupControlEMeter.Size = new System.Drawing.Size(1088, 67);
            this.groupControlEMeter.TabIndex = 0;
            this.groupControlEMeter.Text = "W-Meter";
            // 
            // lookUpEdit1
            // 
            this.lookUpEdit1.Location = new System.Drawing.Point(387, 36);
            this.lookUpEdit1.Name = "lookUpEdit1";
            this.lookUpEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lookUpEdit1.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("building_id", "", 20, DevExpress.Utils.FormatType.None, "", false, DevExpress.Utils.HorzAlignment.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("building_code", " ")});
            this.lookUpEdit1.Size = new System.Drawing.Size(139, 20);
            this.lookUpEdit1.TabIndex = 25;
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl1.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl1.Location = new System.Drawing.Point(230, 37);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(151, 17);
            this.labelControl1.TabIndex = 26;
            this.labelControl1.Text = "W-Meter Brand/Model :";
            // 
            // gridView2
            // 
            this.gridView2.Name = "gridView2";
            // 
            // xtraScrollableControl1
            // 
            this.xtraScrollableControl1.Controls.Add(this.groupBoxMeterInRoom);
            this.xtraScrollableControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl1.Location = new System.Drawing.Point(7, 74);
            this.xtraScrollableControl1.Name = "xtraScrollableControl1";
            this.xtraScrollableControl1.Size = new System.Drawing.Size(1088, 483);
            this.xtraScrollableControl1.TabIndex = 420;
            // 
            // groupBoxMeterInRoom
            // 
            this.groupBoxMeterInRoom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
            this.groupBoxMeterInRoom.Controls.Add(this.gridControlMeterInRoom);
            this.groupBoxMeterInRoom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxMeterInRoom.Location = new System.Drawing.Point(0, 0);
            this.groupBoxMeterInRoom.Name = "groupBoxMeterInRoom";
            this.groupBoxMeterInRoom.Size = new System.Drawing.Size(1088, 483);
            this.groupBoxMeterInRoom.TabIndex = 3;
            this.groupBoxMeterInRoom.TabStop = false;
            // 
            // gridControlMeterInRoom
            // 
            this.gridControlMeterInRoom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlMeterInRoom.Location = new System.Drawing.Point(3, 17);
            this.gridControlMeterInRoom.MainView = this.gridViewMeterInRoom;
            this.gridControlMeterInRoom.Name = "gridControlMeterInRoom";
            this.gridControlMeterInRoom.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEditReading});
            this.gridControlMeterInRoom.Size = new System.Drawing.Size(1082, 463);
            this.gridControlMeterInRoom.TabIndex = 0;
            this.gridControlMeterInRoom.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewMeterInRoom});
            // 
            // gridViewMeterInRoom
            // 
            this.gridViewMeterInRoom.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumnRoomName,
            this.gridColumnMeterName,
            this.gridColumnPreviousDate,
            this.gridColumnPreviousEnergy,
            this.gridColumnPresentRecordDate,
            this.gridColumnPresentEnergy,
            this.gridColumnTotalUnit,
            this.gridColumnReading,
            this.gridColumnConnection,
            this.gridMeterCut,
            this.gridColumnPreviousEnergyTemp,
            this.gridColumnPreviousDateTemp,
            this.gridColumnflag_type_previous,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumnE_MeterID});
            this.gridViewMeterInRoom.GridControl = this.gridControlMeterInRoom;
            this.gridViewMeterInRoom.Name = "gridViewMeterInRoom";
            this.gridViewMeterInRoom.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumnRoomName
            // 
            this.gridColumnRoomName.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnRoomName.AppearanceHeader.Options.UseFont = true;
            this.gridColumnRoomName.Caption = "Room Name";
            this.gridColumnRoomName.FieldName = "room_label";
            this.gridColumnRoomName.Name = "gridColumnRoomName";
            this.gridColumnRoomName.OptionsColumn.AllowEdit = false;
            this.gridColumnRoomName.OptionsColumn.AllowFocus = false;
            this.gridColumnRoomName.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnRoomName.OptionsColumn.AllowMove = false;
            this.gridColumnRoomName.OptionsColumn.ReadOnly = true;
            this.gridColumnRoomName.Visible = true;
            this.gridColumnRoomName.VisibleIndex = 0;
            this.gridColumnRoomName.Width = 77;
            // 
            // gridColumnMeterName
            // 
            this.gridColumnMeterName.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnMeterName.AppearanceHeader.Options.UseFont = true;
            this.gridColumnMeterName.Caption = "Meter Name";
            this.gridColumnMeterName.FieldName = "meter_label";
            this.gridColumnMeterName.Name = "gridColumnMeterName";
            this.gridColumnMeterName.OptionsColumn.AllowEdit = false;
            this.gridColumnMeterName.OptionsColumn.AllowFocus = false;
            this.gridColumnMeterName.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnMeterName.OptionsColumn.AllowMove = false;
            this.gridColumnMeterName.OptionsColumn.ReadOnly = true;
            this.gridColumnMeterName.Visible = true;
            this.gridColumnMeterName.VisibleIndex = 1;
            this.gridColumnMeterName.Width = 96;
            // 
            // gridColumnPreviousDate
            // 
            this.gridColumnPreviousDate.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnPreviousDate.AppearanceHeader.Options.UseFont = true;
            this.gridColumnPreviousDate.Caption = "Previous Date (Billing)";
            this.gridColumnPreviousDate.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumnPreviousDate.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumnPreviousDate.FieldName = "wprevious_date_billing";
            this.gridColumnPreviousDate.Name = "gridColumnPreviousDate";
            this.gridColumnPreviousDate.OptionsColumn.AllowEdit = false;
            this.gridColumnPreviousDate.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPreviousDate.OptionsColumn.AllowMove = false;
            this.gridColumnPreviousDate.Visible = true;
            this.gridColumnPreviousDate.VisibleIndex = 2;
            this.gridColumnPreviousDate.Width = 134;
            // 
            // gridColumnPreviousEnergy
            // 
            this.gridColumnPreviousEnergy.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnPreviousEnergy.AppearanceHeader.Options.UseFont = true;
            this.gridColumnPreviousEnergy.Caption = "Previous Unit (Billing)";
            this.gridColumnPreviousEnergy.DisplayFormat.FormatString = "n3";
            this.gridColumnPreviousEnergy.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnPreviousEnergy.FieldName = "wprevious_energy_billing";
            this.gridColumnPreviousEnergy.Name = "gridColumnPreviousEnergy";
            this.gridColumnPreviousEnergy.OptionsColumn.AllowEdit = false;
            this.gridColumnPreviousEnergy.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPreviousEnergy.OptionsColumn.AllowMove = false;
            this.gridColumnPreviousEnergy.Visible = true;
            this.gridColumnPreviousEnergy.VisibleIndex = 3;
            this.gridColumnPreviousEnergy.Width = 146;
            // 
            // gridColumnPresentRecordDate
            // 
            this.gridColumnPresentRecordDate.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnPresentRecordDate.AppearanceHeader.Options.UseFont = true;
            this.gridColumnPresentRecordDate.Caption = "Present Record Date";
            this.gridColumnPresentRecordDate.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumnPresentRecordDate.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumnPresentRecordDate.FieldName = "wpresent_date_update";
            this.gridColumnPresentRecordDate.Name = "gridColumnPresentRecordDate";
            this.gridColumnPresentRecordDate.OptionsColumn.AllowEdit = false;
            this.gridColumnPresentRecordDate.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPresentRecordDate.OptionsColumn.AllowMove = false;
            this.gridColumnPresentRecordDate.Visible = true;
            this.gridColumnPresentRecordDate.VisibleIndex = 4;
            this.gridColumnPresentRecordDate.Width = 126;
            // 
            // gridColumnPresentEnergy
            // 
            this.gridColumnPresentEnergy.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnPresentEnergy.AppearanceHeader.Options.UseFont = true;
            this.gridColumnPresentEnergy.Caption = "Present Unit";
            this.gridColumnPresentEnergy.DisplayFormat.FormatString = "n3";
            this.gridColumnPresentEnergy.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnPresentEnergy.FieldName = "wpresent_energy_value";
            this.gridColumnPresentEnergy.Name = "gridColumnPresentEnergy";
            this.gridColumnPresentEnergy.OptionsColumn.AllowEdit = false;
            this.gridColumnPresentEnergy.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnPresentEnergy.OptionsColumn.AllowMove = false;
            this.gridColumnPresentEnergy.Visible = true;
            this.gridColumnPresentEnergy.VisibleIndex = 5;
            this.gridColumnPresentEnergy.Width = 110;
            // 
            // gridColumnTotalUnit
            // 
            this.gridColumnTotalUnit.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnTotalUnit.AppearanceHeader.Options.UseFont = true;
            this.gridColumnTotalUnit.Caption = "Total Unit";
            this.gridColumnTotalUnit.DisplayFormat.FormatString = "n3";
            this.gridColumnTotalUnit.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnTotalUnit.FieldName = "total_unit";
            this.gridColumnTotalUnit.Name = "gridColumnTotalUnit";
            this.gridColumnTotalUnit.OptionsColumn.AllowEdit = false;
            this.gridColumnTotalUnit.OptionsColumn.AllowFocus = false;
            this.gridColumnTotalUnit.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnTotalUnit.OptionsColumn.AllowMove = false;
            this.gridColumnTotalUnit.OptionsColumn.ReadOnly = true;
            this.gridColumnTotalUnit.Visible = true;
            this.gridColumnTotalUnit.VisibleIndex = 6;
            this.gridColumnTotalUnit.Width = 76;
            // 
            // gridColumnReading
            // 
            this.gridColumnReading.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnReading.AppearanceHeader.Options.UseFont = true;
            this.gridColumnReading.Caption = "Read";
            this.gridColumnReading.ColumnEdit = this.repositoryItemButtonEditReading;
            this.gridColumnReading.Name = "gridColumnReading";
            this.gridColumnReading.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnReading.OptionsColumn.AllowMove = false;
            this.gridColumnReading.OptionsColumn.ReadOnly = true;
            this.gridColumnReading.Visible = true;
            this.gridColumnReading.VisibleIndex = 7;
            this.gridColumnReading.Width = 49;
            // 
            // repositoryItemButtonEditReading
            // 
            this.repositoryItemButtonEditReading.AccessibleDescription = "Read";
            this.repositoryItemButtonEditReading.AccessibleName = "Read";
            this.repositoryItemButtonEditReading.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.repositoryItemButtonEditReading.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Ellipsis, "Read", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, null, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, true)});
            this.repositoryItemButtonEditReading.ButtonsStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.repositoryItemButtonEditReading.Name = "repositoryItemButtonEditReading";
            this.repositoryItemButtonEditReading.NullText = "Read";
            this.repositoryItemButtonEditReading.NullValuePrompt = "Read";
            this.repositoryItemButtonEditReading.NullValuePromptShowForEmptyValue = true;
            this.repositoryItemButtonEditReading.ReadOnly = true;
            this.repositoryItemButtonEditReading.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repositoryItemButtonEditReading.UseParentBackground = true;
            // 
            // gridColumnConnection
            // 
            this.gridColumnConnection.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gridColumnConnection.AppearanceHeader.Options.UseFont = true;
            this.gridColumnConnection.Caption = "Meter Connection";
            this.gridColumnConnection.FieldName = "E_CommStatus";
            this.gridColumnConnection.Name = "gridColumnConnection";
            this.gridColumnConnection.OptionsColumn.AllowEdit = false;
            this.gridColumnConnection.OptionsColumn.AllowFocus = false;
            this.gridColumnConnection.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
            this.gridColumnConnection.OptionsColumn.AllowMove = false;
            this.gridColumnConnection.OptionsColumn.ReadOnly = true;
            this.gridColumnConnection.Visible = true;
            this.gridColumnConnection.VisibleIndex = 8;
            this.gridColumnConnection.Width = 109;
            // 
            // gridMeterCut
            // 
            this.gridMeterCut.Caption = "Meter Cut";
            this.gridMeterCut.FieldName = "meter_cut";
            this.gridMeterCut.Name = "gridMeterCut";
            // 
            // gridColumnPreviousEnergyTemp
            // 
            this.gridColumnPreviousEnergyTemp.Caption = "previous_energy_billing ( Temp )";
            this.gridColumnPreviousEnergyTemp.DisplayFormat.FormatString = "n1";
            this.gridColumnPreviousEnergyTemp.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumnPreviousEnergyTemp.FieldName = "previous_energy_billingTemp";
            this.gridColumnPreviousEnergyTemp.Name = "gridColumnPreviousEnergyTemp";
            this.gridColumnPreviousEnergyTemp.Visible = true;
            this.gridColumnPreviousEnergyTemp.VisibleIndex = 9;
            this.gridColumnPreviousEnergyTemp.Width = 165;
            // 
            // gridColumnPreviousDateTemp
            // 
            this.gridColumnPreviousDateTemp.Caption = "previous_date_billingTemp";
            this.gridColumnPreviousDateTemp.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumnPreviousDateTemp.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumnPreviousDateTemp.FieldName = "previous_date_billingTemp";
            this.gridColumnPreviousDateTemp.Name = "gridColumnPreviousDateTemp";
            this.gridColumnPreviousDateTemp.Visible = true;
            this.gridColumnPreviousDateTemp.VisibleIndex = 10;
            this.gridColumnPreviousDateTemp.Width = 136;
            // 
            // gridColumnflag_type_previous
            // 
            this.gridColumnflag_type_previous.Caption = "Flag";
            this.gridColumnflag_type_previous.FieldName = "flag_type_previous";
            this.gridColumnflag_type_previous.Name = "gridColumnflag_type_previous";
            this.gridColumnflag_type_previous.Width = 29;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "present_energy_valueTemp( Temp )";
            this.gridColumn8.DisplayFormat.FormatString = "n1";
            this.gridColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn8.FieldName = "present_energy_valueTemp";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 11;
            this.gridColumn8.Width = 184;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "present_date_updateTemp";
            this.gridColumn9.DisplayFormat.FormatString = "{0:yyyy-MM-dd}";
            this.gridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.gridColumn9.FieldName = "present_date_updateTemp";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 12;
            this.gridColumn9.Width = 140;
            // 
            // gridColumnE_MeterID
            // 
            this.gridColumnE_MeterID.Caption = "gridColumnE_MeterID";
            this.gridColumnE_MeterID.FieldName = "water_id";
            this.gridColumnE_MeterID.Name = "gridColumnE_MeterID";
            this.gridColumnE_MeterID.Width = 113;
            // 
            // Recording_WMeter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.xtraScrollableControl1);
            this.Controls.Add(this.panelControl8);
            this.Controls.Add(this.groupControlEMeter);
            this.Name = "Recording_WMeter";
            this.Padding = new System.Windows.Forms.Padding(7);
            this.Size = new System.Drawing.Size(1102, 647);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl8)).EndInit();
            this.panelControl8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditBuilding.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEditRecordDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControlEMeter)).EndInit();
            this.groupControlEMeter.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lookUpEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            this.xtraScrollableControl1.ResumeLayout(false);
            this.groupBoxMeterInRoom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlMeterInRoom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewMeterInRoom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditReading)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl8;
        private DevExpress.XtraEditors.SimpleButton bttEdit;
        private DevExpress.XtraEditors.SimpleButton bttCancel;
        private DevExpress.XtraEditors.SimpleButton bttSave;
        private DevExpress.XtraEditors.SimpleButton bttReplace;
        private DevExpress.XtraEditors.LabelControl labelControlBuilding;
        private DevExpress.XtraEditors.LookUpEdit lookUpEditBuilding;
        private DevExpress.XtraEditors.LabelControl labelControlRecordDate;
        private DevExpress.XtraEditors.LookUpEdit lookUpEditRecordDate;
        private DevExpress.XtraEditors.GroupControl groupControlEMeter;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl1;
        private System.Windows.Forms.GroupBox groupBoxMeterInRoom;
        private DevExpress.XtraGrid.GridControl gridControlMeterInRoom;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewMeterInRoom;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnRoomName;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnMeterName;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPreviousDate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPreviousEnergy;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPresentRecordDate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPresentEnergy;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnTotalUnit;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnReading;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnConnection;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditReading;
        private DevExpress.XtraGrid.Columns.GridColumn gridMeterCut;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPreviousEnergyTemp;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnPreviousDateTemp;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnflag_type_previous;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnE_MeterID;
        private DevExpress.XtraEditors.LookUpEdit lookUpEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
    }
}
